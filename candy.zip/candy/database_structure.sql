-- phpMyAdmin SQL Dump
-- version 2.11.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 02, 2009 at 12:27 PM
-- Server version: 5.0.41
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `candy`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE IF NOT EXISTS `addresses` (
  `id` smallint(6) NOT NULL auto_increment,
  `street` varchar(200) NOT NULL,
  `default` binary(1) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `addresses_addresstypes`
--

CREATE TABLE IF NOT EXISTS `addresses_addresstypes` (
  `id` smallint(6) NOT NULL auto_increment,
  `address_id` smallint(6) NOT NULL,
  `addresstype_id` smallint(6) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Table structure for table `addresses_locations`
--

CREATE TABLE IF NOT EXISTS `addresses_locations` (
  `id` smallint(6) NOT NULL auto_increment,
  `address_id` smallint(6) NOT NULL,
  `location_id` smallint(6) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- Table structure for table `addresses_people`
--

CREATE TABLE IF NOT EXISTS `addresses_people` (
  `id` smallint(6) NOT NULL auto_increment,
  `address_id` smallint(6) NOT NULL,
  `person_id` smallint(6) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Table structure for table `addresstypes`
--

CREATE TABLE IF NOT EXISTS `addresstypes` (
  `id` smallint(6) NOT NULL auto_increment,
  `type` varchar(80) NOT NULL,
  `shortcode` char(3) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `text` text NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
  `id` smallint(6) NOT NULL auto_increment,
  `name` varchar(120) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `companies_industries`
--

CREATE TABLE IF NOT EXISTS `companies_industries` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `company_id` smallint(5) unsigned NOT NULL,
  `industry_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `companies_locations`
--

CREATE TABLE IF NOT EXISTS `companies_locations` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `company_id` smallint(5) unsigned NOT NULL,
  `location_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `companies_workexperiences`
--

CREATE TABLE IF NOT EXISTS `companies_workexperiences` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `company_id` int(10) unsigned NOT NULL,
  `workexperience_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` smallint(6) NOT NULL auto_increment,
  `name` varchar(80) NOT NULL,
  `numcode` smallint(6) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=240 ;

-- --------------------------------------------------------

--
-- Table structure for table `countries_locations`
--

CREATE TABLE IF NOT EXISTS `countries_locations` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `country_id` smallint(6) NOT NULL,
  `location_id` smallint(6) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `degrees`
--

CREATE TABLE IF NOT EXISTS `degrees` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `degrees_qualifications`
--

CREATE TABLE IF NOT EXISTS `degrees_qualifications` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `degree_id` smallint(5) unsigned NOT NULL,
  `qualification_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `degrees_qualificationtypes`
--

CREATE TABLE IF NOT EXISTS `degrees_qualificationtypes` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `degree_id` smallint(5) unsigned NOT NULL,
  `qualificationtype_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `designations`
--

CREATE TABLE IF NOT EXISTS `designations` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `designations_workexperiences`
--

CREATE TABLE IF NOT EXISTS `designations_workexperiences` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `designation_id` int(10) unsigned NOT NULL,
  `workexperience_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `emails`
--

CREATE TABLE IF NOT EXISTS `emails` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `address` varchar(100) NOT NULL,
  `default` binary(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `emails_people`
--

CREATE TABLE IF NOT EXISTS `emails_people` (
  `id` smallint(6) NOT NULL auto_increment,
  `email_id` smallint(6) NOT NULL,
  `person_id` smallint(6) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL,
  `title` varchar(20) NOT NULL default '',
  `description` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `industries`
--

CREATE TABLE IF NOT EXISTS `industries` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `industries_segments`
--

CREATE TABLE IF NOT EXISTS `industries_segments` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `industry_id` smallint(5) unsigned NOT NULL,
  `segment_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `industries_workexperiences`
--

CREATE TABLE IF NOT EXISTS `industries_workexperiences` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `industry_id` smallint(5) unsigned NOT NULL,
  `workexperience_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `institutes`
--

CREATE TABLE IF NOT EXISTS `institutes` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `institutes_qualifications`
--

CREATE TABLE IF NOT EXISTS `institutes_qualifications` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `institute_id` smallint(5) unsigned NOT NULL,
  `qualification_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE IF NOT EXISTS `locations` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `city` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `locations_workexperiences`
--

CREATE TABLE IF NOT EXISTS `locations_workexperiences` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `location_id` int(10) unsigned NOT NULL,
  `workexperience_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `organisations`
--

CREATE TABLE IF NOT EXISTS `organisations` (
  `bsecode` text NOT NULL,
  `name` varchar(80) NOT NULL,
  `indcode` tinyint(4) NOT NULL,
  `industry` varchar(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE IF NOT EXISTS `people` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `firstname` varchar(80) NOT NULL,
  `middlename` varchar(80) default NULL,
  `lastname` varchar(80) default NULL,
  `gender` enum('M','F') NOT NULL,
  `dob` date default NULL,
  `resume` varchar(20) default NULL,
  `created` datetime NOT NULL,
  `updated` datetime default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `resume` (`resume`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `people_phones`
--

CREATE TABLE IF NOT EXISTS `people_phones` (
  `id` smallint(6) NOT NULL auto_increment,
  `person_id` smallint(6) NOT NULL,
  `phone_id` smallint(6) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `people_qualifications`
--

CREATE TABLE IF NOT EXISTS `people_qualifications` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `person_id` smallint(5) unsigned NOT NULL,
  `qualification_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `people_workexperiences`
--

CREATE TABLE IF NOT EXISTS `people_workexperiences` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `person_id` smallint(5) unsigned NOT NULL,
  `workexperience_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `phones`
--

CREATE TABLE IF NOT EXISTS `phones` (
  `id` smallint(6) NOT NULL auto_increment,
  `number` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `phones_phonetypes`
--

CREATE TABLE IF NOT EXISTS `phones_phonetypes` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `phone_id` smallint(6) NOT NULL,
  `phonetype_id` smallint(6) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `phonetypes`
--

CREATE TABLE IF NOT EXISTS `phonetypes` (
  `id` smallint(6) NOT NULL auto_increment,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `qualifications`
--

CREATE TABLE IF NOT EXISTS `qualifications` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `coursetype` enum('FT','PT','C') NOT NULL COMMENT 'FT = Full Time, PT = Part Time, C = Correspondence',
  `from_date` year(4) default NULL,
  `to_date` year(4) default NULL,
  `score` text,
  `rank` binary(1) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Table structure for table `qualifications_qualificationtypes`
--

CREATE TABLE IF NOT EXISTS `qualifications_qualificationtypes` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `qualification_id` smallint(5) unsigned NOT NULL,
  `qualificationtype_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `qualificationtypes`
--

CREATE TABLE IF NOT EXISTS `qualificationtypes` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(40) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- Table structure for table `responsibilities`
--

CREATE TABLE IF NOT EXISTS `responsibilities` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(40) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `responsibility` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `responsibilities_workexperiences`
--

CREATE TABLE IF NOT EXISTS `responsibilities_workexperiences` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `responsibility_id` smallint(5) unsigned NOT NULL,
  `workexperience_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `responsibility_id` (`responsibility_id`,`workexperience_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `segments`
--

CREATE TABLE IF NOT EXISTS `segments` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `segments_workexperiences`
--

CREATE TABLE IF NOT EXISTS `segments_workexperiences` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `segment_id` smallint(5) unsigned NOT NULL,
  `workexperience_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `group_id` int(11) NOT NULL default '1',
  `identifier` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `verticals`
--

CREATE TABLE IF NOT EXISTS `verticals` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `vertical` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `verticals_workexperiences`
--

CREATE TABLE IF NOT EXISTS `verticals_workexperiences` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `vertical_id` smallint(5) unsigned NOT NULL,
  `workexperience_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `vertical_id` (`vertical_id`,`workexperience_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `workexperiences`
--

CREATE TABLE IF NOT EXISTS `workexperiences` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `from_date` date NOT NULL,
  `to_date` date default NULL,
  `salary_fixed` decimal(10,0) unsigned default NULL,
  `salary_variable` decimal(10,0) unsigned default NULL,
  `created` datetime NOT NULL,
  `updated` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `workexperiences_workexperiencetypes`
--

CREATE TABLE IF NOT EXISTS `workexperiences_workexperiencetypes` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `workexperience_id` smallint(5) unsigned NOT NULL,
  `workexperiencetype_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `workexperience_id` (`workexperience_id`,`workexperiencetype_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `workexperiencetypes`
--

CREATE TABLE IF NOT EXISTS `workexperiencetypes` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `type` varchar(40) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;
