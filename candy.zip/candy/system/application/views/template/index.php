<html>
<head>
    <title>Xajax 0.5 test</title>
    <?=$xajax_js?>
</head>

<body>
  <h1><?=$content?></h1>
</body>
</html>