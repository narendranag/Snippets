<?
$this->load->view('template/header');
$this->load->view($view, $data);
$this->load->view('template/footer');
?>