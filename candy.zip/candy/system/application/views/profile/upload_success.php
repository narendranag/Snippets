<?php $this->load->view('template/header'); ?>

<h4>Upload</h4>
<div>
	<br/>
	<ul>
		<li>Your file was successfully uploaded!</li>
		<li><?php echo anchor("profile/edit/$id", 'Edit Profile'); ?></li>
	</ul>
</div>

<?php $this->load->view('template/footer'); ?>