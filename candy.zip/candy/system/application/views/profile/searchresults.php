<h4>Search Results</h4>
<br/>
<?php

if( isset($error) )
	echo "No Matches Found ...";
else
{	
	foreach($id as $key => $val)
	{
		echo "<ul class='clear'>";
		echo "<li style='width: 100px;'>" . anchor("/profile/edit/$val", $name[$key]) . "</li>";
		echo "<li style='width: 100px;'>" . $designation[$key] . "</li>";
		echo "<li style='width: 100px;'>" . $company[$key] . "</li>";
		echo "<li style='width: 100px;'>" . $phone[$key] . "</li>";
		
		if(isset($resume[$key]))
			echo "<li style='width: 100px;'>" . anchor($resume[$key], 'Download Resume') . "</li>";
		else
			echo "<li style='width: 100px;'>" . anchor("/profile/upload/$val", 'Upload Resume') . "</li>";
		echo "</ul>";
	}
}
?>