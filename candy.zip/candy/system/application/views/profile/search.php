<h4>Search</h4>
<?=form_open('/profile/search', 'search_form');?>
<br/>
<ul>
	<li><label>Name</label><br/><input type="text" name="name" value="" id="name" size="40"></li>
	<li><label>Email Address</label><br/><input type="text" name="email" value="" id="email" size="40"></li>
	<li><label>Phone Number</label><br/><input type="text" name="phone" value="" id="phone" size="10"></li>
	<li><br/><?echo form_submit('submit', 'Find');?>
</ul>
<ul class="clear">
	<li><label>Industry</label><br/><?=$list_of_industries;?></li>
	<li><label>Segment</label><br/><?=$list_of_segments;?></li>
	<li><label>Function</label><br/><?=$list_of_verticals;?></li>
	<li><label>Role</label><br/><?=$list_of_responsibilities;?></li>
	<li><label>Company</label><br/><?=$list_of_companies;?></li>
	<li><label>Location</label><br/><?=$list_of_worklocations;?></li>
	<li><label>Degree</label><br/><?=$list_of_degrees;?></li>
	<li><label>Institute</label><br/><?=$list_of_institutes;?></li>
</ul>
<?=form_close();?>
<div id="message" class="clear" onclick="$(this).hide();">
	<?php 
	if(isset($message) && ($message != ""))
	{
		echo "<h4>Message</h4>";
		echo "<p>$message</p>";
	}
	?>
</div>
			
