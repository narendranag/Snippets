<?php $this->load->view('template/header'); ?>
<h4>Uplaod</h4>
<div>
	<br/>
<?php echo $error;?>

<?php echo form_open_multipart('legacy/do_upload');?>
<input type="hidden" name="id" value=<?=$id?>>
<ul>
<li><label>Choose Resume ( .doc / .rtf / .pdf)</label><br/>
<input type="file" name="userfile" size="40" />
</li>
</ul>
<ul class="clear">
<li><br/><input type="submit" value="upload" /><li>
	</ul>

</form>
</div>
<?php $this->load->view('template/footer'); ?>
