<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>WorkerBee</title>
	
	<link rel="stylesheet" href="/css/style.css" type="text/css" media="screen, projection">
	<link rel="stylesheet" href="/css/theme/ui.all.css" type="text/css" media="screen, projection">
	
	<script src="/scripts/jquery-1.2.6.min.js"></script>
	<script src="/scripts/jquery-ui-1.5.3.min.js"></script>
	
	<script type="text/javascript">
 	
	$(function() {
		$('.datepicker').datepicker({
			changeMonth: true,
			changeYear: true,
			yearRange: ('-70:+10')
		});
	});
	
	$(function () {
		add_email();
		add_phone();
		add_address();
		add_workexperience();
		add_qualification();
	})
	
	
	// Functions to extend the form on the fly
	// @author: Narendra Nag
	//
	// These functions allow various sections of the form to grow so that it stays compatible with
	// the PHP scripts in the background
	//

	
	function add_email()
	{
		if ( typeof add_email.vhtml == 'undefined' ) {
	        add_email.vhtml = "<input type=\'hidden\' name=\'emailid[]\' value=0>";
			add_email.vhtml = add_email.vhtml + "<ul>";
			add_email.vhtml = add_email.vhtml +	"<li><label><strong>New</strong> Email Address</label><br/>";
			add_email.vhtml = add_email.vhtml + "<input type=text name=\'email[]\' size=30></li>";
			add_email.vhtml = add_email.vhtml + "</ul>";
	    }
	
		$('#email').append(add_email.vhtml);
	};
	
	function add_phone()
	{
		if ( typeof add_phone.vhtml == 'undefined' ) {
	        add_phone.vhtml = "<input type=\'hidden\' name=\'phoneid[]\' value=0>";
			add_phone.vhtml = add_phone.vhtml + "<ul>";
			add_phone.vhtml = add_phone.vhtml + "<li><label>Phone Type</label><br/>";
			add_phone.vhtml = add_phone.vhtml + "<select id=\'phonetype\' name=\'phonetype[]\' ><option value=\"0\">Phone Type</option><option value=\"1\">Mobile</option><option value=\"2\">Office</option><option value=\"3\">Residence</option></select\'></li>";
			add_phone.vhtml = add_phone.vhtml + "<li><label><strong>New</strong> Phone Number</label><br/>";
			add_phone.vhtml = add_phone.vhtml + "<input type=text name=\'phone[]\' size=10></li>";
			add_phone.vhtml = add_phone.vhtml + "</ul>";
	    }

		$('#phone').append(add_phone.vhtml);
	};
	
	function add_address()
	{
		if ( typeof add_address.vhtml == 'undefined' ) {
	        add_address.vhtml = "<input type=\'hidden\' name=\'addressid[]\' value=0>";
			add_address.vhtml = add_address.vhtml + "<ul class=\'clear\'>";
			add_address.vhtml = add_address.vhtml + "<li><label>Address Type<label><br /><select id=\'addresstype\' name=\'addresstype[]\' ><option value=\"0\">Choose Type</option><option value=\"1\">Office</option><option value=\"2\">Residence</option></select\'></li>";
			add_address.vhtml = add_address.vhtml + "<li><label>Country<label><br /><select id=\'countrylist\' name=\'country[]\' ><option value=\"0\">Country</option><option value=\"1\">Afghanistan</option><option value=\"2\">Albania</option><option value=\"3\">Algeria</option><option value=\"4\">American Samoa</option><option value=\"5\">Andorra</option><option value=\"6\">Angola</option><option value=\"7\">Anguilla</option><option value=\"8\">Antarctica</option><option value=\"9\">Antigua and Barbuda</option><option value=\"10\">Argentina</option><option value=\"11\">Armenia</option><option value=\"12\">Aruba</option><option value=\"13\">Australia</option><option value=\"14\">Austria</option><option value=\"15\">Azerbaijan</option><option value=\"16\">Bahamas</option><option value=\"17\">Bahrain</option><option value=\"18\">Bangladesh</option><option value=\"19\">Barbados</option><option value=\"20\">Belarus</option><option value=\"21\">Belgium</option><option value=\"22\">Belize</option><option value=\"23\">Benin</option><option value=\"24\">Bermuda</option><option value=\"25\">Bhutan</option><option value=\"26\">Bolivia</option><option value=\"27\">Bosnia and Herzegovina</option><option value=\"28\">Botswana</option><option value=\"29\">Bouvet Island</option><option value=\"30\">Brazil</option><option value=\"31\">British Indian Ocean Territory</option><option value=\"32\">Brunei Darussalam</option><option value=\"33\">Bulgaria</option><option value=\"34\">Burkina Faso</option><option value=\"35\">Burundi</option><option value=\"36\">Cambodia</option><option value=\"37\">Cameroon</option><option value=\"38\">Canada</option><option value=\"39\">Cape Verde</option><option value=\"40\">Cayman Islands</option><option value=\"41\">Central African Republic</option><option value=\"42\">Chad</option><option value=\"43\">Chile</option><option value=\"44\">China</option><option value=\"45\">Christmas Island</option><option value=\"46\">Cocos (Keeling) Islands</option><option value=\"47\">Colombia</option><option value=\"48\">Comoros</option><option value=\"49\">Congo</option><option value=\"50\">Congo, the Democratic Republic of the</option><option value=\"51\">Cook Islands</option><option value=\"52\">Costa Rica</option><option value=\"53\">Cote D\'Ivoire</option><option value=\"54\">Croatia</option><option value=\"55\">Cuba</option><option value=\"56\">Cyprus</option><option value=\"57\">Czech Republic</option><option value=\"58\">Denmark</option><option value=\"59\">Djibouti</option><option value=\"60\">Dominica</option><option value=\"61\">Dominican Republic</option><option value=\"62\">Ecuador</option><option value=\"63\">Egypt</option><option value=\"64\">El Salvador</option><option value=\"65\">Equatorial Guinea</option><option value=\"66\">Eritrea</option><option value=\"67\">Estonia</option><option value=\"68\">Ethiopia</option><option value=\"69\">Falkland Islands (Malvinas)</option><option value=\"70\">Faroe Islands</option><option value=\"71\">Fiji</option><option value=\"72\">Finland</option><option value=\"73\">France</option><option value=\"74\">French Guiana</option><option value=\"75\">French Polynesia</option><option value=\"76\">French Southern Territories</option><option value=\"77\">Gabon</option><option value=\"78\">Gambia</option><option value=\"79\">Georgia</option><option value=\"80\">Germany</option><option value=\"81\">Ghana</option><option value=\"82\">Gibraltar</option><option value=\"83\">Greece</option><option value=\"84\">Greenland</option><option value=\"85\">Grenada</option><option value=\"86\">Guadeloupe</option><option value=\"87\">Guam</option><option value=\"88\">Guatemala</option><option value=\"89\">Guinea</option><option value=\"90\">Guinea-Bissau</option><option value=\"91\">Guyana</option><option value=\"92\">Haiti</option><option value=\"93\">Heard Island and Mcdonald Islands</option><option value=\"94\">Holy See (Vatican City State)</option><option value=\"95\">Honduras</option><option value=\"96\">Hong Kong</option><option value=\"97\">Hungary</option><option value=\"98\">Iceland</option><option value=\"99\" selected>India</option><option value=\"100\">Indonesia</option><option value=\"101\">Iran, Islamic Republic of</option><option value=\"102\">Iraq</option><option value=\"103\">Ireland</option><option value=\"104\">Israel</option><option value=\"105\">Italy</option><option value=\"106\">Jamaica</option><option value=\"107\">Japan</option><option value=\"108\">Jordan</option><option value=\"109\">Kazakhstan</option><option value=\"110\">Kenya</option><option value=\"111\">Kiribati</option><option value=\"112\">Korea, Democratic People\'s Republic of</option><option value=\"113\">Korea, Republic of</option><option value=\"114\">Kuwait</option><option value=\"115\">Kyrgyzstan</option><option value=\"116\">Lao People\'s Democratic Republic</option><option value=\"117\">Latvia</option><option value=\"118\">Lebanon</option><option value=\"119\">Lesotho</option><option value=\"120\">Liberia</option><option value=\"121\">Libyan Arab Jamahiriya</option><option value=\"122\">Liechtenstein</option><option value=\"123\">Lithuania</option><option value=\"124\">Luxembourg</option><option value=\"125\">Macao</option><option value=\"126\">Macedonia, the Former Yugoslav Republic of</option><option value=\"127\">Madagascar</option><option value=\"128\">Malawi</option><option value=\"129\">Malaysia</option><option value=\"130\">Maldives</option><option value=\"131\">Mali</option><option value=\"132\">Malta</option><option value=\"133\">Marshall Islands</option><option value=\"134\">Martinique</option><option value=\"135\">Mauritania</option><option value=\"136\">Mauritius</option><option value=\"137\">Mayotte</option><option value=\"138\">Mexico</option><option value=\"139\">Micronesia, Federated States of</option><option value=\"140\">Moldova, Republic of</option><option value=\"141\">Monaco</option><option value=\"142\">Mongolia</option><option value=\"143\">Montserrat</option><option value=\"144\">Morocco</option><option value=\"145\">Mozambique</option><option value=\"146\">Myanmar</option><option value=\"147\">Namibia</option><option value=\"148\">Nauru</option><option value=\"149\">Nepal</option><option value=\"150\">Netherlands</option><option value=\"151\">Netherlands Antilles</option><option value=\"152\">New Caledonia</option><option value=\"153\">New Zealand</option><option value=\"154\">Nicaragua</option><option value=\"155\">Niger</option><option value=\"156\">Nigeria</option><option value=\"157\">Niue</option><option value=\"158\">Norfolk Island</option><option value=\"159\">Northern Mariana Islands</option><option value=\"160\">Norway</option><option value=\"161\">Oman</option><option value=\"162\">Pakistan</option><option value=\"163\">Palau</option><option value=\"164\">Palestinian Territory, Occupied</option><option value=\"165\">Panama</option><option value=\"166\">Papua New Guinea</option><option value=\"167\">Paraguay</option><option value=\"168\">Peru</option><option value=\"169\">Philippines</option><option value=\"170\">Pitcairn</option><option value=\"171\">Poland</option><option value=\"172\">Portugal</option><option value=\"173\">Puerto Rico</option><option value=\"174\">Qatar</option><option value=\"175\">Reunion</option><option value=\"176\">Romania</option><option value=\"177\">Russian Federation</option><option value=\"178\">Rwanda</option><option value=\"179\">Saint Helena</option><option value=\"180\">Saint Kitts and Nevis</option><option value=\"181\">Saint Lucia</option><option value=\"182\">Saint Pierre and Miquelon</option><option value=\"183\">Saint Vincent and the Grenadines</option><option value=\"184\">Samoa</option><option value=\"185\">San Marino</option><option value=\"186\">Sao Tome and Principe</option><option value=\"187\">Saudi Arabia</option><option value=\"188\">Senegal</option><option value=\"189\">Serbia and Montenegro</option><option value=\"190\">Seychelles</option><option value=\"191\">Sierra Leone</option><option value=\"192\">Singapore</option><option value=\"193\">Slovakia</option><option value=\"194\">Slovenia</option><option value=\"195\">Solomon Islands</option><option value=\"196\">Somalia</option><option value=\"197\">South Africa</option><option value=\"198\">South Georgia and the South Sandwich Islands</option><option value=\"199\">Spain</option><option value=\"200\">Sri Lanka</option><option value=\"201\">Sudan</option><option value=\"202\">Suriname</option><option value=\"203\">Svalbard and Jan Mayen</option><option value=\"204\">Swaziland</option><option value=\"205\">Sweden</option><option value=\"206\">Switzerland</option><option value=\"207\">Syrian Arab Republic</option><option value=\"208\">Taiwan, Province of China</option><option value=\"209\">Tajikistan</option><option value=\"210\">Tanzania, United Republic of</option><option value=\"211\">Thailand</option><option value=\"212\">Timor-Leste</option><option value=\"213\">Togo</option><option value=\"214\">Tokelau</option><option value=\"215\">Tonga</option><option value=\"216\">Trinidad and Tobago</option><option value=\"217\">Tunisia</option><option value=\"218\">Turkey</option><option value=\"219\">Turkmenistan</option><option value=\"220\">Turks and Caicos Islands</option><option value=\"221\">Tuvalu</option><option value=\"222\">Uganda</option><option value=\"223\">Ukraine</option><option value=\"224\">United Arab Emirates</option><option value=\"225\">United Kingdom</option><option value=\"226\">United States</option><option value=\"227\">United States Minor Outlying Islands</option><option value=\"228\">Uruguay</option><option value=\"229\">Uzbekistan</option><option value=\"230\">Vanuatu</option><option value=\"231\">Venezuela</option><option value=\"232\">Viet Nam</option><option value=\"233\">Virgin Islands, British</option><option value=\"234\">Virgin Islands, U.s.</option><option value=\"235\">Wallis and Futuna</option><option value=\"236\">Western Sahara</option><option value=\"237\">Yemen</option><option value=\"238\">Zambia</option><option value=\"239\">Zimbabwe</option></select\'></li>";
			add_address.vhtml = add_address.vhtml + "<li><label>Street Address<label><br /><input type=text name=\'street[]\' value=\'\' size=30></li>";
			add_address.vhtml = add_address.vhtml + "<li><label>City<label><br /><select id=\'city\' name=\'location[]\' ><option value=\"0\" selected>Choose City</option><option value=\"1\">Gurgaon</option><option value=\"2\">Noida</option><option value=\"3\">New Delhi</option><option value=\"6\">Jaipur</option></select\'></li>";
			add_address.vhtml = add_address.vhtml + "<li><label><strong>OR New</strong> City : </label><br/><input type=text name=\'newcity[]\'></li>";
			add_address.vhtml = add_address.vhtml + "</ul>";
	    }
		
		$('#address').append(add_address.vhtml);
	};
	
	function add_workexperience()
		{
			if ( typeof add_workexperience.no_workexperience == 'undefined' ) {
		        add_workexperience.no_workexperience = 0;
		    }
		
			var vhtml = "<input type=\'hidden\' name=\'workexperienceid[]\' value=\'0\'>";
			
			if(add_workexperience.no_workexperience > 0)
				vhtml = vhtml + "<hr>";
			vhtml = vhtml + "<ul class=\'clear\'>";
			vhtml = vhtml + "<li><label>Type Of Work</label><br/><select id=\'workexperiencetype\' name=\'workexperiencetype[]\' ><option value=\"0\" selected>Choose Work Type</option><option value=\"1\">Full Time</option><option value=\"2\">Part Time</option><option value=\"3\">CONSULTING</option></select\'></li>";
			vhtml = vhtml + "<li><label>Industry</label><br/><select id=\'industry\' name=\'industry[]\' ><option value=\"0\" selected>Choose Industry</option><option value=\"1\">Banking</option><option value=\"2\">Media</option></select\'></li>";	
			vhtml = vhtml + "<li><label>Segment</label><br/><select id=\'segment\' name=\'segment[]\' ><option value=\"0\" selected>Choose Segment</option><option value=\"1\">Private Banking</option></select\'></li>";
			vhtml = vhtml + "<li><label>Function</label><br/><select id=\'vertical\' name=\'vertical[]\' ><option value=\"0\" selected>Choose Function</option><option value=\"1\">Marketing</option><option value=\"2\">Sales</option><option value=\"3\">Human Resources</option><option value=\"4\">Administration</option><option value=\"5\">Finance</option><option value=\"6\">Legal</option></select\'></li>";
			vhtml = vhtml + "<li><label>Role</label><br/><select id=\'responsibility\' name=\'responsibility[]\' ><option value=\"0\" selected>Choose Role</option><option value=\"1\">Customer Service</option></select\'></li>";
			vhtml = vhtml + "</ul><ul class=\'clear\'>";
			vhtml = vhtml + "<li><label>Company</label><br/><select id=\'company\' name=\'company[]\' ><option value=\"0\" selected>Choose Company</option><option value=\"3\">Future Analysis Private Limited</option><option value=\"2\">Hindustan Times Media Ltd</option><option value=\"1\">Resource Angle</option></select\'></li>";
			vhtml = vhtml + "<li><label><strong>OR New</strong> Company</label><br/><input type=\'text\' name=\'newcompany[]\' size=\'10\' value=\'\'></li>";
			vhtml = vhtml + "<li><label>Location</label><br/><select id=\'worklocation\' name=\'worklocation[]\' ><option value=\"0\" selected>Choose City</option><option value=\"1\">Gurgaon</option><option value=\"2\">Noida</option><option value=\"3\">New Delhi</option><option value=\"6\">Jaipur</option></select\'></li>";
			vhtml = vhtml + "<li><label><strong>OR New</strong> Location</label><br/>";
			vhtml = vhtml + "<input type=\'text\' name=\'newworklocation[]\' size=\'10\' value=\'\' onfocus=\"$(\'#workcountryli_" +  add_workexperience.no_workexperience +"\').show();\"></li>";
			vhtml = vhtml + "<li><span style=\'display:none;\' id=\'workcountryli_" + add_workexperience.no_workexperience + "\' style=\'\'><label>Country</label><br/><select id=\'workcountrylist\' name=\'workcountry[]\' ><option value=\"0\">Country</option><option value=\"1\">Afghanistan</option><option value=\"2\">Albania</option><option value=\"3\">Algeria</option><option value=\"4\">American Samoa</option><option value=\"5\">Andorra</option><option value=\"6\">Angola</option><option value=\"7\">Anguilla</option><option value=\"8\">Antarctica</option><option value=\"9\">Antigua and Barbuda</option><option value=\"10\">Argentina</option><option value=\"11\">Armenia</option><option value=\"12\">Aruba</option><option value=\"13\">Australia</option><option value=\"14\">Austria</option><option value=\"15\">Azerbaijan</option><option value=\"16\">Bahamas</option><option value=\"17\">Bahrain</option><option value=\"18\">Bangladesh</option><option value=\"19\">Barbados</option><option value=\"20\">Belarus</option><option value=\"21\">Belgium</option><option value=\"22\">Belize</option><option value=\"23\">Benin</option><option value=\"24\">Bermuda</option><option value=\"25\">Bhutan</option><option value=\"26\">Bolivia</option><option value=\"27\">Bosnia and Herzegovina</option><option value=\"28\">Botswana</option><option value=\"29\">Bouvet Island</option><option value=\"30\">Brazil</option><option value=\"31\">British Indian Ocean Territory</option><option value=\"32\">Brunei Darussalam</option><option value=\"33\">Bulgaria</option><option value=\"34\">Burkina Faso</option><option value=\"35\">Burundi</option><option value=\"36\">Cambodia</option><option value=\"37\">Cameroon</option><option value=\"38\">Canada</option><option value=\"39\">Cape Verde</option><option value=\"40\">Cayman Islands</option><option value=\"41\">Central African Republic</option><option value=\"42\">Chad</option><option value=\"43\">Chile</option><option value=\"44\">China</option><option value=\"45\">Christmas Island</option><option value=\"46\">Cocos (Keeling) Islands</option><option value=\"47\">Colombia</option><option value=\"48\">Comoros</option><option value=\"49\">Congo</option><option value=\"50\">Congo, the Democratic Republic of the</option><option value=\"51\">Cook Islands</option><option value=\"52\">Costa Rica</option><option value=\"53\">Cote D\'Ivoire</option><option value=\"54\">Croatia</option><option value=\"55\">Cuba</option><option value=\"56\">Cyprus</option><option value=\"57\">Czech Republic</option><option value=\"58\">Denmark</option><option value=\"59\">Djibouti</option><option value=\"60\">Dominica</option><option value=\"61\">Dominican Republic</option><option value=\"62\">Ecuador</option><option value=\"63\">Egypt</option><option value=\"64\">El Salvador</option><option value=\"65\">Equatorial Guinea</option><option value=\"66\">Eritrea</option><option value=\"67\">Estonia</option><option value=\"68\">Ethiopia</option><option value=\"69\">Falkland Islands (Malvinas)</option><option value=\"70\">Faroe Islands</option><option value=\"71\">Fiji</option><option value=\"72\">Finland</option><option value=\"73\">France</option><option value=\"74\">French Guiana</option><option value=\"75\">French Polynesia</option><option value=\"76\">French Southern Territories</option><option value=\"77\">Gabon</option><option value=\"78\">Gambia</option><option value=\"79\">Georgia</option><option value=\"80\">Germany</option><option value=\"81\">Ghana</option><option value=\"82\">Gibraltar</option><option value=\"83\">Greece</option><option value=\"84\">Greenland</option><option value=\"85\">Grenada</option><option value=\"86\">Guadeloupe</option><option value=\"87\">Guam</option><option value=\"88\">Guatemala</option><option value=\"89\">Guinea</option><option value=\"90\">Guinea-Bissau</option><option value=\"91\">Guyana</option><option value=\"92\">Haiti</option><option value=\"93\">Heard Island and Mcdonald Islands</option><option value=\"94\">Holy See (Vatican City State)</option><option value=\"95\">Honduras</option><option value=\"96\">Hong Kong</option><option value=\"97\">Hungary</option><option value=\"98\">Iceland</option><option value=\"99\" selected>India</option><option value=\"100\">Indonesia</option><option value=\"101\">Iran, Islamic Republic of</option><option value=\"102\">Iraq</option><option value=\"103\">Ireland</option><option value=\"104\">Israel</option><option value=\"105\">Italy</option><option value=\"106\">Jamaica</option><option value=\"107\">Japan</option><option value=\"108\">Jordan</option><option value=\"109\">Kazakhstan</option><option value=\"110\">Kenya</option><option value=\"111\">Kiribati</option><option value=\"112\">Korea, Democratic People\'s Republic of</option><option value=\"113\">Korea, Republic of</option><option value=\"114\">Kuwait</option><option value=\"115\">Kyrgyzstan</option><option value=\"116\">Lao People\'s Democratic Republic</option><option value=\"117\">Latvia</option><option value=\"118\">Lebanon</option><option value=\"119\">Lesotho</option><option value=\"120\">Liberia</option><option value=\"121\">Libyan Arab Jamahiriya</option><option value=\"122\">Liechtenstein</option><option value=\"123\">Lithuania</option><option value=\"124\">Luxembourg</option><option value=\"125\">Macao</option><option value=\"126\">Macedonia, the Former Yugoslav Republic of</option><option value=\"127\">Madagascar</option><option value=\"128\">Malawi</option><option value=\"129\">Malaysia</option><option value=\"130\">Maldives</option><option value=\"131\">Mali</option><option value=\"132\">Malta</option><option value=\"133\">Marshall Islands</option><option value=\"134\">Martinique</option><option value=\"135\">Mauritania</option><option value=\"136\">Mauritius</option><option value=\"137\">Mayotte</option><option value=\"138\">Mexico</option><option value=\"139\">Micronesia, Federated States of</option><option value=\"140\">Moldova, Republic of</option><option value=\"141\">Monaco</option><option value=\"142\">Mongolia</option><option value=\"143\">Montserrat</option><option value=\"144\">Morocco</option><option value=\"145\">Mozambique</option><option value=\"146\">Myanmar</option><option value=\"147\">Namibia</option><option value=\"148\">Nauru</option><option value=\"149\">Nepal</option><option value=\"150\">Netherlands</option><option value=\"151\">Netherlands Antilles</option><option value=\"152\">New Caledonia</option><option value=\"153\">New Zealand</option><option value=\"154\">Nicaragua</option><option value=\"155\">Niger</option><option value=\"156\">Nigeria</option><option value=\"157\">Niue</option><option value=\"158\">Norfolk Island</option><option value=\"159\">Northern Mariana Islands</option><option value=\"160\">Norway</option><option value=\"161\">Oman</option><option value=\"162\">Pakistan</option><option value=\"163\">Palau</option><option value=\"164\">Palestinian Territory, Occupied</option><option value=\"165\">Panama</option><option value=\"166\">Papua New Guinea</option><option value=\"167\">Paraguay</option><option value=\"168\">Peru</option><option value=\"169\">Philippines</option><option value=\"170\">Pitcairn</option><option value=\"171\">Poland</option><option value=\"172\">Portugal</option><option value=\"173\">Puerto Rico</option><option value=\"174\">Qatar</option><option value=\"175\">Reunion</option><option value=\"176\">Romania</option><option value=\"177\">Russian Federation</option><option value=\"178\">Rwanda</option><option value=\"179\">Saint Helena</option><option value=\"180\">Saint Kitts and Nevis</option><option value=\"181\">Saint Lucia</option><option value=\"182\">Saint Pierre and Miquelon</option><option value=\"183\">Saint Vincent and the Grenadines</option><option value=\"184\">Samoa</option><option value=\"185\">San Marino</option><option value=\"186\">Sao Tome and Principe</option><option value=\"187\">Saudi Arabia</option><option value=\"188\">Senegal</option><option value=\"189\">Serbia and Montenegro</option><option value=\"190\">Seychelles</option><option value=\"191\">Sierra Leone</option><option value=\"192\">Singapore</option><option value=\"193\">Slovakia</option><option value=\"194\">Slovenia</option><option value=\"195\">Solomon Islands</option><option value=\"196\">Somalia</option><option value=\"197\">South Africa</option><option value=\"198\">South Georgia and the South Sandwich Islands</option><option value=\"199\">Spain</option><option value=\"200\">Sri Lanka</option><option value=\"201\">Sudan</option><option value=\"202\">Suriname</option><option value=\"203\">Svalbard and Jan Mayen</option><option value=\"204\">Swaziland</option><option value=\"205\">Sweden</option><option value=\"206\">Switzerland</option><option value=\"207\">Syrian Arab Republic</option><option value=\"208\">Taiwan, Province of China</option><option value=\"209\">Tajikistan</option><option value=\"210\">Tanzania, United Republic of</option><option value=\"211\">Thailand</option><option value=\"212\">Timor-Leste</option><option value=\"213\">Togo</option><option value=\"214\">Tokelau</option><option value=\"215\">Tonga</option><option value=\"216\">Trinidad and Tobago</option><option value=\"217\">Tunisia</option><option value=\"218\">Turkey</option><option value=\"219\">Turkmenistan</option><option value=\"220\">Turks and Caicos Islands</option><option value=\"221\">Tuvalu</option><option value=\"222\">Uganda</option><option value=\"223\">Ukraine</option><option value=\"224\">United Arab Emirates</option><option value=\"225\">United Kingdom</option><option value=\"226\">United States</option><option value=\"227\">United States Minor Outlying Islands</option><option value=\"228\">Uruguay</option><option value=\"229\">Uzbekistan</option><option value=\"230\">Vanuatu</option><option value=\"231\">Venezuela</option><option value=\"232\">Viet Nam</option><option value=\"233\">Virgin Islands, British</option><option value=\"234\">Virgin Islands, U.s.</option><option value=\"235\">Wallis and Futuna</option><option value=\"236\">Western Sahara</option><option value=\"237\">Yemen</option><option value=\"238\">Zambia</option><option value=\"239\">Zimbabwe</option></select\'></span></li>";
			vhtml = vhtml + "<li><label>Designation</label><br/><select id=\'designation\' name=\'designation[]\'><option value=\"0\" selected>Choose Designation</option><option value=\"-1\">New Designation</option><option value=\"1\">Associate Editor</option><option value=\"2\">Senior Manager</option></select\'></li>";
			vhtml = vhtml + "<li><label><strong>OR New</strong> Designation</label><br/><input type=\'text\' name=\'newdesignation[]\' size=\'10\' value=\'\'></li>";
			vhtml = vhtml + "</ul><ul class=\'clear\'>";
			vhtml = vhtml + "<li><label>Joined</label><br/><input type=\'text\' name=\'fromdate[]\' value=\'\' class=\'datepicker\' size=\'10\'/></li>";
			vhtml = vhtml + "<li><label>Left</label><br/><input type=\'text\' name=\'todate[]\' value=\'\' class=\'datepicker\' size=\'10\'/></li>";
			vhtml = vhtml + "<li><label>Fixed Salary</label><br/><input type=\'text\' name=\'fixedsalary[]\' value=\'\' size=4> <label>(Lacs Per Annum)</label></li>";
			vhtml = vhtml + "<li><label>Variable Salary</label><br/><input type=\'text\' name=\'variablesalary[]\' value=\'\' size=4> <label>(Lacs Per Annum)</label></li>";
			vhtml = vhtml + "</ul>";

			$('#workexperience').append(vhtml);
			add_workexperience.no_workexperience++;
			
			$(function() {
				$('.datepicker').datepicker({
					changeMonth: true,
					changeYear: true,
					yearRange: ('-70:+10')
				});
			});
		};
		
		function add_qualification()
			{
				if ( typeof add_qualification.no_qualification == 'undefined' ) {
			        add_qualification.no_qualification = 0;
			    }

				var vhtml = "<input type=\'hidden\' name=\'qualificationid[]\' value=\'0\'>";

				if(add_qualification.no_qualification > 0)
					vhtml = vhtml + "<hr>";
				vhtml = vhtml + "<ul class=\'clear\'>";
				vhtml = vhtml + "<li><label>Type Of Degree</label><br/><select id=\'qualificationtype\' name=\'qualificationtype[]\' ><option value=\"0\" selected>Qualification Type</option><option value=\"1\">School</option><option value=\"2\">Graduation</option><option value=\"3\">Post Graduation</option><option value=\"4\">Professional Course</option></select\'></li>";
				vhtml = vhtml + "<li><label>Full Time/Part Time etc.</label><br/><select id=\'coursetype\' name=\'coursetype[]\' ><option value=\"0\" selected>Course Type</option><option value=\"FT\">Full Time</option><option value=\"PT\">Part Time</option><option value=\"C\">Correspondence / Distance Learning</option></select\'></li>";
				vhtml = vhtml + "<li><label>Degree</label><br/><select id=\'degree\' name=\'degree[]\'><option value=\"0\" selected>Choose Degree</option><option value=\"-1\">New Degree</option><option value=\"1\">High School</option><option value=\"2\">MBA</option></select\'></li>";
				vhtml = vhtml + "<li><label><strong>OR New</strong> Degree</label><br/>";
				vhtml = vhtml + "<input type=\'text\' name=\'newdegree[]\' value=\'\' id=\'newdegree_" + add_qualification.no_qualification + "\'></li>";
				vhtml = vhtml + "<li><label>Institute/University</label><br/><select id=\'institute\' name=\'institute[]\'><option value=\"0\" selected>Choose Institute</option><option value=\"1\">St. Stephens</option></select\'></li>";
				vhtml = vhtml + "<li><label><strong>OR New</strong> Institute</label><br/>";
				vhtml = vhtml + "<input type=\'text\' name=\'newinstitute[]\' value=\'\' size=\'10\'/ id=\'newinstitute_" + add_qualification.no_qualification + "\'></li>";
				vhtml = vhtml + "<li><label>From</label><br/>";
				vhtml = vhtml + "<input type=\'text\' name=\'qfromdate[]\' value=\'YYYY\' id=\'fromq" + add_qualification.no_qualification + "_date\' size=\'4\' onfocus=\"$(this).value='';\"/></li>";
				vhtml = vhtml + "<li><label>To (Batch)</label><br/>";
				vhtml = vhtml + "<input type=\'text\' name=\'qtodate[]\' value=\'YYYY\' id=\'toq" + add_qualification.no_qualification + "_date\' size=\'4\' onfocus=\"$(this).value='';\"/></li>";
				vhtml = vhtml + "<li><label>Score</label><br/>";
				vhtml = vhtml + "<input type=\'text\' name=\'score[]\' value=\'\' id=\'score\' size=\'5\'></li>";
				vhtml = vhtml + "<li><label>Rank</label><br/>";
				vhtml = vhtml + "<input type=\'checkbox\' name=\'rank[]\' value=\'\' id=\'rank\'></li>";
				vhtml = vhtml + "</ul>";

				$('#qualification').append(vhtml);


				add_qualification.no_qualification++;
			};
		
	
	</script>

</head>
	
<h3>WorkerBee</h3>
<?=$this->load->view('template/navigation');?>
<div id="content">
	
	<?php echo form_open('/profile/save', 'edit_form');?>

	<div id="segment_personal" class="clear">
		<h4 onclick="$('#personal_slider').toggle();">Personal</h4>
		<div id="personal_slider">
		<input type="hidden" name="id" value="<?=isset($id) ? $id : "0";?>" id="id">
		<br/>
		<ul>
		<li><label>First Name </label><br/>
			<input type="text" name="firstname" value="<?=isset($firstname) ? $firstname : "";?>" id="firstname" /></li>
		<li><label>Middle Name</label><br/>
			<input type="text" name="middlename" value="<?=isset($middlename) ? $middlename : "";?>" id="middlename" /></li>
		<li><label>Last Name</label><br/>
			<input type="text" name="lastname" value="<?=isset($lastname) ? $lastname : "";?>" id="lastname" /></li>
		<li><label>Gender</label><br/>
			<?=form_dropdown($gender['name'], $gender['options'], $gender['selected']);?></li>
		<li><label>DOB</label><br/><input type="text" name="dob" value="<?=isset($dob) ? $dob : "";?>" id="dob" class="datepicker" size="10"/></li>
		</ul>
		</div>
	</div>

	<div id="segment_contact_details" class="clear">
	
		<h4 onclick="$('#contact_slider').toggle();">Contact Details</h4>
		<div id="contact_slider">
			<div id="editmenu">
					<img src="/img/icons/email_add.png" border="0" onclick="add_email();" title="Add another email address">
					<img src="/img/icons/telephone_add.png" border="0" onclick="add_phone();" title="Add another phone number">
					<img src="/img/icons/book_add.png" border="0" onclick="add_address();" title="Add another address">
			</div>

			<div id="email" class="clear">
			<? if( isset($emails)): ?>
				<? foreach ($emails as $email) : ?>	
					<input type="hidden" name="emailid[]" value="<?=$email['emailid'];?>">
					<ul>
					<li><label>Email Address</label><br/>
						<input type="text" name="email[]" value="<?=$email['email'];?>" size="30"></li>
					</ul>
				<?endforeach;?>
			<?endif;?>
			</div>

			<div id="phone" class="clear">
			<?if( isset($phones)) : ?>
				<ul>
				<?foreach ($phones as $phone) : ?>
		
				<input type="hidden" name="phoneid[]" value="<?=$phone['phoneid'];?>">
				<li><label>Phone Type</label><br/>
					<?=$phone['list_of_phonetypes'];?></li>
				<li><label>Phone Number</label><br/>
					<input type="text" name="phone[]" value="<?=$phone['phone'];?>" size="10"></li>
				<?endforeach;?>
				</ul>
			<?endif;?>
			</div>

			<div id="address" class="clear">
			<?if( isset($addresses)) : ?>
		
				<?foreach ($addresses as $address) : ?>
				<ul class="clear">	
					<input type="hidden" name="addressid[]" value="<?=$address['addressid']?>">
					<li><label>Address Type<label><br /><?=$address['list_of_addresstypes'];?></li>		
					<li><label>Country<label><br /><?=$address['list_of_countries'];?></li>
					<li><label>Street Address<label><br /><input type="text" name="street[]" value="<?=$address['street']?>" id="street" size="30"/></li>
					<li><label>City<label><br /><?=$address['list_of_locations'];?></li>
					<li><label><strong>OR New</strong> City : </label><br/><input type="text" name="newcity[]" value=""></li>
				</ul>
				<?endforeach;?>
		
			<?endif;?>
			</div>
		</div>
	</div>

	<div id="segment_workexperience" class="clear">
		<h4 onclick="$('#work_slider').toggle();">Work Experience</h4>
		<div id="work_slider">
			<div id="editmenu">
				<img src="/img/icons/add.png" border="0" onclick="add_workexperience();" title="Add more work experience"></td></tr>
			</div>
			<div id="workexperience">
			<?if( isset($workexperiences)) : ?>
				<?foreach($workexperiences as $work) : ?>
					<ul>
					<input type="hidden" name="workexperienceid[]" value="<?=$work['workid'];?>">
					<li><label>Type Of Work<label><br /><?=$work['list_of_workexperiencetypes'];?></li>
					<li><label>Industry<label><br /><?=$work['list_of_industries'];?></li>
					<li><label>Segment<label><br /><?=$work['list_of_segments'];?></li>
					<li><label>Function<label><br /><?=$work['list_of_verticals'];?></li>
					<li><label>Role<label><br /><?=$work['list_of_responsibilities'];?></li>
					</ul><ul class="clear">
					<li><label>Company<label><br /><?=$work['list_of_companies'];?></li>
					<li><label><strong>OR New</strong> Company</label><br/><input type="text" name="newcompany[]" size="10" value=""></li>
				
					<li><label>Location<label><br /><?=$work['list_of_worklocations'];?></li>
					<li><label><strong>OR New</strong> Location</label><br/><input type="text" name="newworklocation[]" size="10" value="" onfocus="$('#wl_<?=$work['workid'];?>').show();"></li>
					<li><span style="display:none;" id="wl_<?=$work['workid'];?>"><label>Country</label><br/><?=$list_of_workcountries;?></span></li>
					<li><label>Designation</label><br><?=$work['list_of_designations'];?></li>
					<li><label><strong>OR New</strong> Designation</label><br><input type="text" name="newdesignation[]" size="10" value=""></li>
					</ul>
					<ul class="clear">
					<li><label>Joined</label><br/>
						<input type="text" name="fromdate[]" value="<?=$work['fromdate'];?>" id="from_<?=$work['workid'];?>" class="datepicker" size="10"/></li>
					<li><label>Left</label><br/>
						<input type="text" name="todate[]" value="<?=$work['todate'];?>" id="to_<?=$work['workid'];?>" class="datepicker" size="10"/></li>
					<li><label>Fixed Salary</label><br/><input type="text" name="fixedsalary[]" value="<?=$work['salary_fixed'];?>" size=4> <label>(Lacs Per Annum)</label></li>
	
					<li><label>Variable Salary</label><br/><input type="text" name="variablesalary[]" value="<?=$work['salary_variable'];?>" size=4> <label>(Lacs Per Annum)</label></li>
				</ul>
				<hr>
				<?php

					endforeach;
				endif;?>
			</div>
		</div>
	</div>

	<div id="segment_qualification">
		<h4 onclick="$('#qualification_slider').toggle();">Academic Qualifications</h4>
		<div id="qualification_slider">
			<div id="editmenu">
				<img src="/img/icons/add.png" border="0" onclick="add_qualification();" title="Add more academic details"></td></tr>
			</div>	
			<div id="qualification">

			<?php 
			if (isset($qualifications)) :
				foreach($qualifications as $qualification) :?>
				<input type="hidden" name="qualificationid[]" value="<?=$qualification['id'];?>">
	
				<ul class="clear">
		
				<li><label>Type Of Degree</label><br/><?=$qualification['list_of_qualificationtypes'];?></li>
				<li><label>Full Time/Part Time etc.</label><br/><?=form_dropdown($qualification['coursetypes']['name'], $qualification['coursetypes']['options'], $qualification['coursetypes']['selected']);?></li>
				<li><label>Degree</label><br/><?=$qualification['list_of_degrees'];?></li>
				<li><label><strong>OR New</strong> Degree</label><br/><input type="text" name="newdegree[]" value="" id="new_degree_<?=$qualification['id'];?>"></li>
				<li><label>Institute/University</label><br/><?=$qualification['list_of_institutes'];?></li>
				<li><label><strong>OR New</strong> Institute</label><br/><input type="text" name="newinstitute[]" value="" id="new_institute_<?=$qualification['id'];?>" size="10"></li>
				<li><label>From</label><br/><input type="text" name="qfromdate[]" value="<?=isset($qualification['fromdate']) ? $qualification['fromdate'] : "";?>" size="4"/>
				<li><label>To (Batch)</label><br/><input type="text" name="qtodate[]" value="<?=isset($qualification['todate']) ? $qualification['todate']: "";?>"  size="4"/> 
				<li><label>Score</label><br/><input type="text" name="score[]" value="<?=$qualification['score']?>" id="score" size="5"></li>
				<li><label>Rank</label><br/><input type="checkbox" name="rank[]" value="<?=$qualification['rank']?>" id="rank"></li>
				</ul>
				<hr>
				<script>
					Event.observe("imgFrom_q_<?=$qualification['id'];?>_Date", "click", imgCalendar_Click.bindAsEventListener(this, "from_q_<?=$qualification['id'];?>_date"));
					Event.observe("imgTo_q_<?=$qualification['id'];?>_Date", "click", imgCalendar_Click.bindAsEventListener(this, "to_q_<?=$qualification['id'];?>_date"));
				</script>
			<?php  
				endforeach;
			endif;
			?>
			</div>
		</div>
	</div>

	<div id="submit_div" class="clear">
		<?php
		 	echo form_submit('submit', 'Submit To Database') . "<label> or " . anchor('/profile', 'Cancel') . "</label>";
			echo form_close();	
		?>
		
	</div>
</div>
</body>
</html>


