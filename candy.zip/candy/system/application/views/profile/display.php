<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>WorkerBee</title>
	
	<link rel="stylesheet" href="/css/demo.css" type="text/css" media="screen, projection">
</head>

<body>

	<div id="container">
		<h3 class="clear"><?=$firstname . " " . $middlename . " " . $lastname;?></h4>
		<p><?=($gender['selected'] == 'M') ? "Male, " : "Female, ";?><?=$dob?></p>
		

		<div id="segment_contact_details" class="clear">
			<div id="email" class="clear">
			<? if( isset($emails)): ?>
				<? foreach ($emails as $email) : ?>	
					<p><?=$email['email'];?></p>
				<?endforeach;?>
			<?endif;?>
			</div>

			<div id="phone" class="clear">
			<?if( isset($phones)) : ?>
				<p><strong>Phone</strong></p>
				<?foreach ($phones as $phone) : ?>
					<p><?=$phone['list_of_phonetypes'];?> : <?=$phone['phone'];?></p>
				<?endforeach;?>
			<?endif;?>
			</div>

			<div id="address" class="clear">
			<?if( isset($addresses)) : ?>
				<p><strong>Address</strong></p>
				<?foreach ($addresses as $address) : ?>
					<p><?=$address['list_of_addresstypes'];?></p>
					<p><?=$address['street']?><br/>
						<?=$address['list_of_locations'];?>, <?=$address['list_of_countries'];?></p>
					<hr>
				<?endforeach;?>
			<?endif;?>
			</div>
		</div>

		<div id="segment_workexperience" class="clear">
			
				<div id="workexperience">
				<?if( isset($workexperiences)) : ?>
				<h5>Work Experience</h5>
					<?foreach($workexperiences as $work) : ?>
						<li><?=$work['list_of_workexperiencetypes'];?></li>
						<li><?=$work['list_of_industries'];?></li>
						<li><?=$work['list_of_segments'];?></li>
						<li><?=$work['list_of_verticals'];?></li>
						<li><?=$work['list_of_responsibilities'];?></li>
						<li><?=$work['list_of_companies'];?></li>
						<li><?=$work['list_of_worklocations'];?></li>
						<li><label>New Company: </label><input type="text" name="newcompany[]" value=""></li>
						<li><label>From : </label>
							<input type="text" name="fromdate[]" value="<?=$work['fromdate'];?>" id="from_<?=$work['workid'];?>" size="10"/> 
							<img src="/img/icons/date.png" id="imgFromDate_<?=$work['workid'];?>" /></li>
						<li><label>To : </label><input type="text" name="todate[]" value="<?=$work['todate'];?>" id="to_<?=$work['workid'];?>" size="10"/> 
							<img src="/img/icons/date.png" id="imgToDate_<?=$work['workid'];?>" /></li>

						<li><label>Fixed : </label><input type="text" name="fixedsalary[]" value="<?=$work['salary_fixed'];?>" size=4> <label>(Lacs Per Annum)</label></li>

						<li><label>Variable : </label><input type="text" name="variablesalary[]" value="<?=$work['salary_variable'];?>" size=4> <label>(Lacs Per Annum)</label></li>
					<?php
						echo "<script>
								add_event_observer(\"imgFromDate_" . $work['workid'] . "\", \"from_" . $work['workid'] . "\");
								add_event_observer(\"imgToDate_" . $work['workid'] . "\", \"to_" . $work['workid'] . "\");
							</script>";

						endforeach;
					?>
				</ul>
				<?endif;?>
				</div>
			</div>
		</div>

		<div id="segment_qualification">
			<h4 onclick="$('qualification_slider').toggle();">Academic Qualifications</h4>
			<div id="qualification_slider">
				<div id="menu">
					<img src="/img/icons/add.png" border="0" onclick="add_qualification();" title="Add more academic details"></td></tr>
				</div>	
				<div id="div_full_of_qualifications">

				<?php 
				if (isset($qualifications)) :
					foreach($qualifications as $qualification) :?>
					<input type="hidden" name="qualificationid[]" value="<?=$qualification['id'];?>">

					<ul class="clear">

					<li><?=$qualification['list_of_qualificationtypes'];?></li>
					<li><?=form_dropdown($qualification['coursetype']['name'], $qualification['coursetype']['options'], $qualification['coursetype']['selected']);?></li>
					<li><?=$qualification['list_of_degrees'];?></li>
					<li><label>New Degree : </label><input type="text" name="newdegree[]" value="" id="new_degree_<?=$qualification['id'];?>"></li>
					<li><?=$qualification['list_of_institutes'];?></li>
					<li><input type="text" name="newinstitute[]" value="" id="new_institute_<?=$qualification['id'];?>"></li>
					<li><input type="text" name="qfromdate[]" value="<?=isset($fromdate) ? $fromdate : "";?>" id="from_q_<?=$qualification['id'];?>_date" size="10"/> 
						<img src="/img/icons/date.png" id="imgFrom_q_<?=$qualification['id'];?>_Date" /></li>
					<li><input type="text" name="qtodate[]" value="<?=isset($todate) ? $todate : "";?>" id="to_q_<?=$qualification['id'];?>_date" size="10"/> 
						<img src="/img/icons/date.png" id="imgTo_q_<?=$qualification['id'];?>_Date" /></li>
					<li><input type="text" name="score[]" value="" id="score" size="5"></li>
					<li><input type="checkbox" name="rank[]" value="" id="rank"></li>

					</ul>
					<script>
						Event.observe("imgFrom_q_<?=$qualification['id'];?>_Date", "click", imgCalendar_Click.bindAsEventListener(this, "from_q_<?=$qualification['id'];?>_date"));
						Event.observe("imgTo_q_<?=$qualification['id'];?>_Date", "click", imgCalendar_Click.bindAsEventListener(this, "to_q_<?=$qualification['id'];?>_date"));
					</script>
				<?php  
					endforeach;
				endif;
				?>
				</div>
			</div>
		</div>

		<!--

		<fieldset class="alt">
			<legend>Comments</legend>
			<?=form_textarea($comments);?>
		</fieldset>
		<p style='clear:both'>
		***
		-->
		<div id="submit_div" class="clear">
			<?php
			 	echo form_submit('submit', 'Submit To Database') . "<label> or " . anchor('/profile', 'Cancel') . "</label>";
				echo form_close();	
			?>

		</div>
	</div>
	</body>