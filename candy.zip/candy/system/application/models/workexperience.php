<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Workexperience extends DataMapper
{
	var $has_one = array('person', 'workexperiencetype', "industry", "segment", "vertical", "responsibility", 'company', 'designation', 'location');
	
	function Workexperience()
	{
		parent::DataMapper();
	}
}
?>