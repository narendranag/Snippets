<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Person extends DataMapper
{
	
	var $table = "people";
	var $model = "person";
	var $has_many = array('address','phone', 'email', 'workexperience', 'qualification');
	
	var $auto_populate_has_many = TRUE;
	
	function Person()
	{
		parent::DataMapper();
	}
	
	function split_name($name)
	{
		$firstname = ucwords(strtolower(trim($name)));
		$middlename = "";
		$lastname = "";	
	
		if(strpos($firstname, " ")) {
			list($firstname, $lastname) = explode(" ", $firstname, 2);
	
			if(strpos($lastname, " ")) {
				list($middlename, $lastname) = explode(" ", $lastname, 2);
			}
		}
		
		return array('firstname' => $firstname, 'middlename' => $middlename, 'lastname' => $lastname);
	}
	
}
?>