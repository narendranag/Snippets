<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Organisation extends DataMapper
{
	function Organisation()
	{
		parent::DataMapper();
	}
}

?>