<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Designation extends DataMapper
{
	var $has_many = array('workexperience');
	
	function Designation()
	{
		parent::DataMapper();
	}
}
?>