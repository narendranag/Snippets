<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Segment extends DataMapper
{	
	//var $has_one = array("industry");
	var $has_many = array("workexperience");
	
	function Segment()
	{
		parent::DataMapper();
	}
}
?>