<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Comment extends DataMapper
{
	var $has_one = array("user", "person");
	
	function Comment()
	{
		parent::DataMapper();
	}
}
?>