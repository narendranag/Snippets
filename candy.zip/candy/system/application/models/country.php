<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Country extends DataMapper
{
	var $table = "countries";
	var $model = "country";
	
	var $has_many = array('location');
	
	function Country()
	{
		parent::DataMapper();
	}
}