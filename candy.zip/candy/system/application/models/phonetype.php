<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Phonetype extends DataMapper
{
	var $has_many = array('phone');
	
	function Phonetype()
	{
		parent::DataMapper();
	}
}
?>