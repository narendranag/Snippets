<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
Qualifications

qualification_type -> qualificationtype
degree -> degrees
institute -> institutes
from_date
to_date
score
rank [y/n]


*/

class Qualification extends DataMapper
{
	var $has_one = array("person", "qualificationtype", "degree", "institute");
	
	function Qualification()
	{
		parent::DataMapper();
	}
}
?>