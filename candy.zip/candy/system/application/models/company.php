<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Company extends DataMapper
{
	var $table = "companies";

	var $has_many = array("location", "workexperience", "industry");

	function Company()
	{
		parent::DataMapper();
	}
}
?>