<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Group extends DataMapper
{
	var $has_many = array("user");
	
	function Group()
	{
		parent::DataMapper();
	}
}
?>