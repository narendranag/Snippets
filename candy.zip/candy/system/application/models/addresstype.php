<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Addresstype extends DataMapper
{
	var $has_many = array('address');

	
	function Addresstype()
	{
		parent::DataMapper();
	}
}
?>