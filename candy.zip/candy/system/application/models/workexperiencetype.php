<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Workexperiencetype extends DataMapper
{
	var $has_many = array('workexperience');
	
	function Workexperiencetype()
	{
		parent::DataMapper();
	}
}
?>