<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Responsibility extends DataMapper
{	
	var $table = "responsibilities";
	var $model = "responsibility";
	
	var $has_many = array("workexperience");
	
	function Responsibility()
	{
		parent::DataMapper();
	}
}
?>