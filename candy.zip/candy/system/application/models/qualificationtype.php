<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Qualificationtype extends DataMapper
{
	var $has_many = array("qualification");
	
	function Qualificationtype()
	{
		parent::DataMapper();
	}
}