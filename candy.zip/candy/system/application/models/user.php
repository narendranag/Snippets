<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class User extends DataMapper
{
	var $has_many = array("comment");
	
	function User()
	{
		parent::DataMapper();
	}
}
?>