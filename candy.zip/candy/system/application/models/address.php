<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Address extends DataMapper
{
	
	var $table = "addresses";
	var $model = "address";
	
	var $has_one = array("person", "location", "addresstype");
	
	function Address()
	{
		parent::DataMapper();
	}
	
}
?>