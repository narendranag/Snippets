<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Email extends DataMapper
{
	var $has_one = array('person');
	
	var $auto_populate_has_one = TRUE;
	
	function Email()
	{
		parent::DataMapper();
	}
}
?>