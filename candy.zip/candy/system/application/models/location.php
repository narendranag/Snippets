<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* - - - - - - - - 

@table 
		locations
@fields
		id
		location

- - - - - - - - - */
class Location extends DataMapper
{	
	var $has_many = array('address', 'workexperience');
	var $has_one = array('country');

	function Location()
	{
		parent::DataMapper();
	}
}
?>