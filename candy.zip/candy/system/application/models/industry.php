<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Industry extends DataMapper
{
	var $table = "industries";
	var $model = "industry";

	var $has_many = array("segment" , "workexperience" , "company");
	
	function Industry()
	{
		parent::DataMapper();
	}
}
?>