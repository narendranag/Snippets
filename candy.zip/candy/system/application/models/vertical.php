<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Vertical extends DataMapper
{
	var $has_many = array("workexperiences");
	
	function Vertical()
	{
		parent::DataMapper();
	}
}
?>