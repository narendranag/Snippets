<?php

/*

The Main Profile Controller

Program Flow:

													 		+------>	Edit	<-----+			
															|						  |
			+--------->	Search ----> List Search Results ---+---> View Single Profile +
			|												|
Dashboard --+												|
		 	|												|
			+----->	Add ---->-------------------------------+


METHODS:

index()  				// Shows the search form 
search()				// Data from search form is passed to this method which then performs a search
list($query_result) 	// populates and loads the list view
show($id)				PRIVATE // Populates and loads the show view
edit($id)				// Populates and loads the add/edit form
save()					// Adds/Updates profile and then shows the updated profile
get_list()				// Gets a list of values from a table -- used to build dropdown lists

VIEWS:
profile/search
profile/list
profile/show
profile/edit

*/

class Profile extends Application 
{

	var $data;

	function Profile() 
	{
		parent::Application();
		if(! $this->auth->logged_in())
			$this->auth->login();
		$this->load->helper('date');
	}
	
	function login()
	{
		$this->auth->login();
	}
	
	function register()
	{
		$this->auth->register();
	}
	
	function logout()
	{
		$this->auth->logout();
	}
	
	// The Main Dashboard
	function index($message = "")
	{
		if($this->auth->logged_in())
		{
			$this->data['list_of_industries'] = $this->build_list_of_industries();
			$this->data['list_of_segments'] = $this->build_list_of_segments();
			$this->data['list_of_verticals'] = $this->build_list_of_verticals();
			$this->data['list_of_responsibilities'] = $this->build_list_of_responsibilities();
			$this->data['list_of_companies'] = $this->build_list_of_companies();
			$this->data['list_of_designations'] = $this->build_list_of_designations();
			$this->data['list_of_worklocations'] = $this->build_list_of_worklocations();
			$this->data['list_of_institutes'] = $this->build_list_of_institutes();
			$this->data['list_of_degrees'] = $this->build_list_of_degrees();
			$this->data['message'] = $message;
		
			$templatedata['view'] = 'profile/search';
			$templatedata['data'] = $this->data;
			$this->load->view('template', $templatedata);
		}
	}
	

	function upload($id)
	{
		$this->load->view('profile/upload_form', array('error' => ' ', 'id' => $id ));
	}

	function do_upload()
	{
		$config['upload_path'] = './uploads/';
		$config['allowed_types'] = 'doc|rtf|txt|pdf';
		$config['max_size']	= '100';
		$config['max_width']  = '1024';
		$config['max_height']  = '768';
		
		$this->load->library('upload', $config);
	
		if ( ! $this->upload->do_upload())
		{
			$error = array('error' => $this->upload->display_errors());
			
			$this->load->view('profile/upload_form', $error);
		}	
		else
		{
			$p = new Person();
			$p->get_by_id($id);
			$data = array('upload_data' => $this->upload->data());
			$p->resume = $data['upload_data']['full_path'];
			$p->save();
			$data['id'] = $p->id;
			$this->load->view('profile/upload_success', $data);
		}
	}
	
	// The Search Function
	function search()
	{
		$person = new Person();
		
		$index = 0;

		$passed_val = $this->input->post('name');
		
		if(!empty($passed_val))
		{
			$splitname = $person->split_name($passed_val);
			
			if($splitname['firstname'] != "")
				$person->like('firstname', $splitname['firstname']);
			if($splitname['middlename'] != "")
				$person->like('middlename', $splitname['middlename']);
			if($splitname['lastname'] != "")
				$person->like('lastname', $splitname['lastname']);
			
			foreach ($person->get()->all as $row)
			{
				$id[$index]	= $row->id;
				$name[$index] = $row->firstname;
				$name[$index] .= ($row->middlename != "") ? " " . $row->middlename : "";
				$name[$index] .= ($row->lastname != "") ? " " . $row->lastname : "";
				
				$designation[$index] = $person->workexperience->designation->name;
				$company[$index] = $person->workexperience->company->name;
				$location[$index] = $person->workexperience->location->city;
				$phone[$index] = $row->phone->number;
				$resume[$index] = $row->resume;
				
				$index++;
			}
		}
		
		$passed_val = $this->input->post('email');
		
		if(!empty($passed_val))
		{
			$e = new Email();
			$e->like('address', $passed_val)->get();
			foreach ($e->person->get()->all as $row)
			{
				$id[$index]	= $row->id;
				$name[$index] = $row->firstname;
				$name[$index] .= ($row->middlename != "") ? " " . $row->middlename : "";
				$name[$index] .= ($row->lastname != "") ? " " . $row->lastname : "";	
				$designation[$index] = $person->workexperience->designation->name;
				$company[$index] = $person->workexperience->company->name;
				$location[$index] = $person->workexperience->location->city;
				$phone[$index] = $row->phone->number;
				$resume[$index] = $row->resume;
				
				$index++;
			}
		}
		
		$passed_val = $this->input->post('phone');
		
		if(!empty($passed_val))
		{
			$p = new Phone();
			$p->like('number', $passed_val)->get();
			foreach ($p->person->get()->all as $row)
			{
				$id[$index]	= $row->id;
				$name[$index] = $row->firstname;
				$name[$index] .= ($row->middlename != "") ? " " . $row->middlename : "";
				$name[$index] .= ($row->lastname != "") ? " " . $row->lastname : "";	
				$designation[$index] = $person->workexperience->designation->name;
				$company[$index] = $person->workexperience->company->name;
				$location[$index] = $person->workexperience->location->city;
				$phone[$index] = $row->phone->number;
				$resume[$index] = $row->resume;
				
				$index++;
			}
			
		}
		
		$passed_val = $this->input->post('industry');
		
		if($passed_val[0] != 0)
		{
			$w = new Workexperience();
			$w->where_related_industry('id', $passed_val[0])->get();
			
			foreach ($w->person->get()->all as $row)
			{
				$i = 0;
				$flag = TRUE;
				
				if(isset($id))
				{
					while($i < $index)
					{
						if($row->id == $id[$i])
							$flag = FALSE;
						$i++;
					}
				}
				
				if($flag)
				{
					$id[$index]	= $row->id;
					$name[$index] = $row->firstname;
					$name[$index] .= ($row->middlename != "") ? " " . $row->middlename : "";
					$name[$index] .= ($row->lastname != "") ? " " . $row->lastname : "";	
					$designation[$index] = $person->workexperience->designation->name;
					$company[$index] = $person->workexperience->company->name;
					$location[$index] = $person->workexperience->location->city;
					$phone[$index] = $row->phone->number;
					$resume[$index] = $row->resume;
				
					$index++;
				}
			}
			
		}
		
		$passed_val = $this->input->post('segment');
		
		if($passed_val[0] != 0)
		{
			$w = new Workexperience();
			$w->where_related_segment('id', $passed_val[0])->get();
			
			foreach ($w->person->get()->all as $row)
			{
				$i = 0;
				$flag = TRUE;
				
				if(isset($id))
				{
					while($i <= $index)
					{
						if($row->id == $id[$i])
							$flag = FALSE;
						$i++;
					}
				}
				
				if($flag)
				{
					$id[$index]	= $row->id;
					$name[$index] = $row->firstname;
					$name[$index] .= ($row->middlename != "") ? " " . $row->middlename : "";
					$name[$index] .= ($row->lastname != "") ? " " . $row->lastname : "";	
					$designation[$index] = $person->workexperience->designation->name;
					$company[$index] = $person->workexperience->company->name;
					$location[$index] = $person->workexperience->location->city;
					$phone[$index] = $row->phone->number;
					$resume[$index] = $row->resume;
				
					$index++;
				}
			}
			
		}
		
		$passed_val = $this->input->post('vertical');
		
		if($passed_val[0] != 0)
		{
			$w = new Workexperience();
			$w->where_related_vertical('id', $passed_val[0])->get();
			
			foreach ($w->person->get()->all as $row)
			{
				$i = 0;
				$flag = TRUE;
				
				if(isset($id))
				{
					while($i <= $index)
					{
						if($row->id == $id[$i])
							$flag = FALSE;
						$i++;
					}
				}
				
				if($flag)
				{
					$id[$index]	= $row->id;
					$name[$index] = $row->firstname;
					$name[$index] .= ($row->middlename != "") ? " " . $row->middlename : "";
					$name[$index] .= ($row->lastname != "") ? " " . $row->lastname : "";	
					$designation[$index] = $person->workexperience->designation->name;
					$company[$index] = $person->workexperience->company->name;
					$location[$index] = $person->workexperience->location->city;
					$phone[$index] = $row->phone->number;
					$resume[$index] = $row->resume;
				
					$index++;
				}
			}
			
			$passed_val = $this->input->post('responsibility');

			if($passed_val[0] != 0)
			{
				$w = new Workexperience();
				$w->where_related_responsibility('id', $passed_val[0])->get();

				foreach ($w->person->get()->all as $row)
				{
					$i = 0;
					$flag = TRUE;

					if(isset($id))
					{
						while($i <= $index)
						{
							if($row->id == $id[$i])
								$flag = FALSE;
							$i++;
						}
					}

					if($flag)
					{
						$id[$index]	= $row->id;
						$name[$index] = $row->firstname;
						$name[$index] .= ($row->middlename != "") ? " " . $row->middlename : "";
						$name[$index] .= ($row->lastname != "") ? " " . $row->lastname : "";	
						$designation[$index] = $person->workexperience->designation->name;
						$company[$index] = $person->workexperience->company->name;
						$location[$index] = $person->workexperience->location->city;
						$phone[$index] = $row->phone->number;
						$resume[$index] = $row->resume;

						$index++;
					}
				}

			}
			
			$passed_val = $this->input->post('worklocation');

			if($passed_val[0] != 0)
			{
				$w = new Workexperience();
				$w->where_related_location('id', $passed_val[0])->get();

				foreach ($w->person->get()->all as $row)
				{
					$i = 0;
					$flag = TRUE;

					if(isset($id))
					{
						while($i <= $index)
						{
							if($row->id == $id[$i])
								$flag = FALSE;
							$i++;
						}
					}

					if($flag)
					{
						$id[$index]	= $row->id;
						$name[$index] = $row->firstname;
						$name[$index] .= ($row->middlename != "") ? " " . $row->middlename : "";
						$name[$index] .= ($row->lastname != "") ? " " . $row->lastname : "";	
						$designation[$index] = $person->workexperience->designation->name;
						$company[$index] = $person->workexperience->company->name;
						$location[$index] = $person->workexperience->location->city;
						$phone[$index] = $row->phone->number;
						$resume[$index] = $row->resume;

						$index++;
					}
				}

			}
			
			$passed_val = $this->input->post('degree');

			if($passed_val[0] != 0)
			{
				$w = new Qualification();
				$w->where_related_degree('id', $passed_val[0])->get();

				foreach ($w->person->get()->all as $row)
				{
					$i = 0;
					$flag = TRUE;

					if(isset($id))
					{
						while($i <= $index)
						{
							if($row->id == $id[$i])
								$flag = FALSE;
							$i++;
						}
					}

					if($flag)
					{
						$id[$index]	= $row->id;
						$name[$index] = $row->firstname;
						$name[$index] .= ($row->middlename != "") ? " " . $row->middlename : "";
						$name[$index] .= ($row->lastname != "") ? " " . $row->lastname : "";	
						$designation[$index] = $person->workexperience->designation->name;
						$company[$index] = $person->workexperience->company->name;
						$location[$index] = $person->workexperience->location->city;
						$phone[$index] = $row->phone->number;
						$resume[$index] = $row->resume;

						$index++;
					}
				}

			}
			
			$passed_val = $this->input->post('institute');

			if($passed_val[0] != 0)
			{
				$w = new Qualification();
				$w->where_related_institute('id', $passed_val[0])->get();

				foreach ($w->person->get()->all as $row)
				{
					$i = 0;
					$flag = TRUE;

					if(isset($id))
					{
						while($i <= $index)
						{
							if($row->id == $id[$i])
								$flag = FALSE;
							$i++;
						}
					}

					if($flag)
					{
						$id[$index]	= $row->id;
						$name[$index] = $row->firstname;
						$name[$index] .= ($row->middlename != "") ? " " . $row->middlename : "";
						$name[$index] .= ($row->lastname != "") ? " " . $row->lastname : "";	
						$designation[$index] = $person->workexperience->designation->name;
						$company[$index] = $person->workexperience->company->name;
						$location[$index] = $person->workexperience->location->city;
						$phone[$index] = $row->phone->number;
						$resume[$index] = $row->resume;

						$index++;
					}
				}

			}
		}
		
		if(isset($id))
		{
			$data['id'] = $id;
			$data['name'] = $name;
			$data['designation'] = $designation;
			$data['company'] = $company;
			$data['phone'] = $phone;
		}
		else
			$data['error'] = "No matches";
			
		$templatedata['view'] =  'profile/searchresults';
		$templatedata['data'] = $data;
		$this->load->view('template',$templatedata);
	}
	
	// Sets up the Add/Edit View
	function edit($id = NULL)
	{
		
		// If an id has been provided, then we go into edit mode.
		//
		if(! $this->auth->logged_in())
			return;
		
		if($id)
		{
			$this->populate_data($id);
		}
		else
			$this->build_gender_list();
			
		// Create all our standard lists that will be used everywhere
		// Create List of AddressTypes

		$this->data['list_of_addresstypes'] = $this->build_list_of_addresstypes();
		$this->data['list_of_countries'] = $this->build_list_of_countries();
		$this->data['list_of_cities'] = $this->build_list_of_cities();
		$this->data['list_of_phonetypes'] = $this->build_list_of_phonetypes();
		$this->data['list_of_workexperiencetypes'] = $this->build_list_of_workexperiencetypes();
		$this->data['list_of_industries'] = $this->build_list_of_industries();
		$this->data['list_of_segments'] = $this->build_list_of_segments();
		$this->data['list_of_verticals'] = $this->build_list_of_verticals();
		$this->data['list_of_responsibilities'] = $this->build_list_of_responsibilities();
		$this->data['list_of_companies'] = $this->build_list_of_companies();
		$this->data['list_of_designations'] = $this->build_list_of_designations();
		$this->data['list_of_worklocations'] = $this->build_list_of_worklocations();
		$this->data['list_of_workcountries'] = $this->build_list_of_workcountries();
		
		$this->data['list_of_qualificationtypes'] = $this->build_list_of_qualificationtypes();
		$this->data['list_of_coursetypes'] = $this->build_list_of_coursetypes();
		$this->data['list_of_institutes'] = $this->build_list_of_institutes();
		$this->data['list_of_degrees'] = $this->build_list_of_degrees();
		
	
		// FINALLY, LOAD THE VIEW
		$this->load->view('profile/edit', $this->data);

		
		
	}
	
	
	function save()
	{	
		if(! $this->auth->logged_in())
			return;
		
		$person = new Person();
				
		if($this->input->post('id') != '0')
		{
			$person->get_by_id($this->input->post('id'));
		}
		
		$person->firstname = $this->input->post('firstname');
		$person->middlename = $this->input->post('middlename');
		$person->lastname = $this->input->post('lastname');
		$person->dob = mdate($this->input->post('dob'));
		$person->gender = $this->input->post('gender');
		
		$person->save();
		
		$emailids = $this->input->post('emailid');
		$emails = $this->input->post('email');
		
		foreach ($emails as $key => $value) :
			
			$e = new Email();
			
			if($emailids[$key] > 0)
			{
				$e->get_by_id($emailids[$key]);
				if(strlen(trim($value)) > 0)
				{
					$e->address = $value;
					$e->save($person);
				}
				else
				{
					$e->delete();
				}
			}
			else
			{
				if(strlen($value) > 0)
				{	
					$e->address = $value;
					$e->save($person);
				}	
			}
		endforeach;
		
		
		
		$phonetypes = $this->input->post('phonetype');
		$phoneids = $this->input->post('phoneid');
		$phones = $this->input->post('phone');
		
		foreach ($phones as $key => $value) :
			$p = new Phone();
			$t = new Phonetype();
			
			$t->get_by_id($phonetypes[$key]);

			if($phoneids[$key] > 0)
			{
				$p->get_by_id($phoneids[$key]);
				
				if(strlen($value) > 0)
				{
					$p->number = $value;
					if($p->phonetype->id != $t->id)
					{
						$temp_t = new Phonetype();
						$temp_t->where('id', $p->phonetype->id)->get();
						$p->delete($temp_t);
						$p->save(array($person, $t));
					}
					else
					{
						$p->save($person);
					}
						
				}
				else
				{
					$p->delete();
				}
			}
			else
			{
				if(strlen($value) > 0)
				{
					$p->number = $value;
					$p->save(array($person, $t));
				}
			}
		endforeach;
		

		
		$addressids = $this->input->post('addressid');
		$addresstypes = $this->input->post('addresstype');
		$addresses = $this->input->post('street');
		$locations = $this->input->post('location');
		$newcities = $this->input->post('newcity');
		$countries = $this->input->post('country');
		
		foreach ($addresses as $key => $value) :
		
			if(trim($value) != "Street Address") // Since we got a default value in the form, we don't want to save it
			{
			
				$a = new Address();
				
				// Set up all related values
				
				$at = new Addresstype();
				$at->get_by_id($addresstypes[$key]);
			
				$c = new Country();
				$c->get_by_id($countries[$key]);
			
				$l = new Location();
			
				if(strlen(trim($newcities[$key])) > 0)
				{
					$l->city = $newcities[$key];
					$l->save($c);
				}
				else
				{
					$l->get_by_id($locations[$key]);
				}
			
				// Now start saving the address, and it's relationships
				
				if($addressids[$key] > 0)
				{
					$a->get_by_id($addressids[$key]);
					
					if(strlen($value) > 0) // Check if a value hasn't been deleted
					{
						$a->street = $value;
						
						// Check if addresstype has changed, if it has
						// delete the old relationship
						if($a->addresstype->id != $at->id)
						{
							$temp = new Addresstype();
							$temp->where('id', $a->addresstype->id)->get();
							$a->delete($temp);
						}
						
						// Check if location has changed, if it has
						// delete the old relationship
						
						if($a->location->id != $l->id)
						{
							$temp = new Location();
							$temp->where('id', $a->location->id)->get();
							$a->delete($temp);
						}
						
						// Save the address and it's relationships
						
						$a->save(array($person, $at, $l));
					}
					else
					{
						$a->delete();
					}
				}
				else
				{
					if(strlen($value) > 0)	
					{
						$a->street = $value;	
						$a->save(array($person, $at, $l));
					}
				}	
			}
		endforeach;
		
		
		$workids 				= $this->input->post('workexperienceid');
		$workexperiencetypes	= $this->input->post('workexperiencetype');
		$industries				= $this->input->post('industry');
		$segments				= $this->input->post('segment');
		$verticals				= $this->input->post('vertical');
		$responsibilities 		= $this->input->post('responsibility');
		$companies				= $this->input->post('company');
		$newcompanies 			= $this->input->post('newcompany');
		$worklocations			= $this->input->post('worklocation');
		$workcountries			= $this->input->post('workcountry');
		$newworklocations 		= $this->input->post('newworklocation');
		$designations 			= $this->input->post('designation');
		$newdesignations 		= $this->input->post('newdesignation');
		$fromdates				= $this->input->post('fromdate');
		$todates				= $this->input->post('todate');
		$fixsalaries 			= $this->input->post('fixedsalary');
		$varsalaries			= $this->input->post('variablesalary');
		
		
		foreach ($workids as $key => $id) :
		
			// Check if there is a new record to add
			// For workexperience, if a fromdate has beend defined
			// we're in business
			
			if( strlen($fromdates[$key]) != 0 )
			{	

				$w = new Workexperience();
				$wt = new Workexperiencetype();
				$i = new Industry();
				$s = new Segment();
				$v = new Vertical();
				$r = new Responsibility();
				$c = new Company();
				$d = new Designation();
				$l = new Location();
				$country = new Country();
				
				// Get all values for relationships
				
				$wt->get_by_id($workexperiencetypes[$key]);
				
				$i->get_by_id($industries[$key]);
				$s->get_by_id($segments[$key]);
				$v->get_by_id($verticals[$key]);
				$r->get_by_id($responsibilities[$key]);
				
				// Check if there is a new company/designation/location being added
				// or pick up the selected value from the list
				
				if(strlen(trim($newcompanies[$key])) > 0)
				{
					$c->name = $newcompanies[$key];
					$c->save();
				}
				else
					$c->get_by_id($companies[$key]);

				if(strlen(trim($newdesignations[$key])) > 0)
				{
					$d->name = $newdesignations[$key];
					$d->save();
				}
				else
					$d->get_by_id($designations[$key]);

				if(strlen(trim($newworklocations[$key])) > 0)
				{
					$country->get_by_id($workcountries[$key]);
					$l->name = $newworklocations[$key];
					$l->save($country);
				}
				else
					$l->get_by_id($worklocations[$key]);
			
				// Head into update mode if a record exists
				//
				if($id != 0)
				{
					$w->get_by_id($id);
					
					// Check if the entire entry is to be deleted
					
					if($workexperiencetypes[$key] == 0)
						$w->delete();
					else
					{
						// Assign values from the form:

						$w->from_date = mdate($fromdates[$key]);
						$w->to_date = mdate($todates[$key]);
						$w->salary_fixed = $fixsalaries[$key];
						$w->salary_variable = $varsalaries[$key];
						
						// Check if there is a change in any of the relationships
						// delete old ones
						
						if($w->workexperiencetype->id != $wt->id)
						{
							$temp = new Workexperiencetype();
							$temp->where('id', $w->workexperiencetype->id)->get();
							$w->delete($temp);
						}
						
						if($w->industry->id != $i->id)
						{
							$temp = new Industry();
							$temp->where('id', $w->industry->id)->get();
							$w->delete($temp);
						}
						
						if($w->segment->id != $s->id)
						{
							$temp = new Segment();
							$temp->where('id', $w->segment->id)->get();
							$w->delete($temp);
						}
						
						if($w->vertical->id != $v->id)
						{
							$temp = new vertical();
							$temp->where('id', $w->vertical->id)->get();
							$w->delete($temp);
						}
						
						if($w->responsibility->id != $r->id)
						{
							$temp = new Responsibility();
							$temp->where('id', $w->responsibility->id)->get();
							$w->delete($temp);
						}
						
						if($w->company->id != $c->id)
						{
							$temp = new Company();
							$temp->where('id', $w->company->id)->get();
							$w->delete($temp);
						}
						
						if($w->location->id != $l->id)
						{
							$temp = new Location();
							$temp->where('id', $w->location->id)->get();
							$w->delete($temp);
						}
					
						// Update the record
						
						$w->save(array($person, $wt, $i, $s, $v, $r, $c, $d, $l));
					}
			
				}
				else
				{
					// Now we know this is a new record,
					// so we assign values to $w
					
					$w->from_date = mdate($fromdates[$key]);
					$w->to_date = mdate($todates[$key]);
					$w->salary_fixed = $fixsalaries[$key];
					$w->salary_variable = $varsalaries[$key];
					
					$w->save(array($person, $wt, $i, $s, $v, $r, $c, $d, $l));
				}
			}


		endforeach;
		
		
		
		$qualificationids = $this->input->post('qualificationid');
		$qualificationtypes = $this->input->post('qualificationtype');
		$coursetypes = $this->input->post('coursetype');
		$degrees = $this->input->post('degree');
		$newdegrees = $this->input->post('newdegree');
		$institutes = $this->input->post('institute');
		$newinstitutes = $this->input->post('newinstitute');
		$fromyears = $this->input->post('qfromdate');
		$toyears = $this->input->post('qtodate');
		$scores = $this->input->post('score');
		$ranks = $this->input->post('rank');
		
		
		foreach ($qualificationids as $key => $id)
		{
				
			// Check if there is anything to update, or if its a blank entry
			// We assume there has to be a toyear 
			
			if( strlen($toyears[$key]) != 0 && ($toyears[$key]!="YYYY"))
			{
				$q = new Qualification();
				
				$qtype = new Qualificationtype();
				
				$d = new Degree();
				$i = new Institute();
				
				// Populate all the relations
				
				$qtype->where('id',$qualificationtypes[$key])->get();
				
				if(strlen(trim($newdegrees[$key])) > 0)
				{
					$d->name = $newdegrees[$key];
					$d->save();
				}
				else
					$d->get_by_id($degrees[$key]);
				
				
				if(strlen(trim($newinstitutes[$key])) > 0)
				{
					$i->name = $newinstitutes[$key];
					$i->save();
				}
				else
					$i->get_by_id($institutes[$key]);
				
				// If the id is defined, then we head into update mode
				
				if($id != 0) // Edit an Existing Record
				{
					
					$q->get_by_id($id);
			
					// Now we check if the entire entry is to be deleted
					
					if ($qualificationtypes[$key] == 0) // Delete the record
					{	
						$q->delete();
					}
					else // Update the recor
					{
						// Now we populate qualification

						$q->coursetype = $coursetypes[$key];
						$q->from_date = $fromyears[$key];
						$q->to_date = $toyears[$key];
						$q->score = $scores[$key];
						$q->rank = $ranks[$key];

						// Now we check if a relationship has changed,
						// if it has we delete the old relationship

						if($q->qualificationtype->id != $qtype->id)
						{
							$temp = new Qualificationtype();
							$temp->where('id', $q->qualificationtype->id)->get();
							$q->delete($temp);
						}

						if($q->degree->id != $d->id)
						{
							$temp = new Degree();
							$temp->where('id', $q->degree->id)->get();
							$q->delete($temp);
						}

						if($q->institute->id != $d->id)
						{
							$temp = new Institute();
							$temp->where('id', $q->institute->id)->get();
							$q->delete($temp);
						}

						// And now we update ...
						
						$q->save(array($person, $qtype, $d, $i));
					}
				}	
				else // Add a new record
				{
					// This is a new record
					
					$q->coursetype = $coursetypes[$key];
					$q->from_date = $fromyears[$key];
					$q->to_date = $toyears[$key];
					$q->score = $scores[$key];
					$q->rank = $ranks[$key];
					
					$q->save(array($person, $qtype, $d, $i));
					
				}
			
			}
			
		}
		
		$this->index('Saved ...');
	}
	
	/*
	function display($id)
	{
		populate_data($id);
		$this->load->('profile/display');
		
	}
*/
	
	// This function populates the data variable with
	// a person's particulars. It is used to 
	// set up the form for an edit as well as the display
	// page
	
	function populate_data($id)
	{
		if(! $this->auth->logged_in())
			return;
		
		// First let's populate personal information
		$person = new Person();
		$person->get_by_id($id);
		
		$this->data['id'] = $person->id;
		$this->data['firstname'] = $person->firstname;
		$this->data['middlename'] = $person->middlename;
		$this->data['lastname'] = $person->lastname;
		$this->data['dob'] = $person->dob;
	
		$this->build_gender_list($person->gender);
	
		// Populate emails/phones/addresses
		$emails = array();
		$phones = array();
		$addresses = array();
		$workexperiences = array();
		$qualifications = array();
		
		// Populate all emails
		if(!empty($person->email->id))
		{
			foreach ($person->email->all as $e)
			{
				$emails[$e->id]['emailid'] = $e->id;
				$emails[$e->id]['email'] = $e->address;
				$emails[$e->id]['default'] = $e->default;
			}
			
			$this->data['emails'] = $emails;
		}
		
		// Populate all phones
		if(!empty($person->phone->id))
		{		
			foreach ($person->phone->all as $p)
			{
				$phones[$p->id]['phoneid'] = $p->id;
				$phones[$p->id]['list_of_phonetypes'] = $this->build_list_of_phonetypes($p->phonetype->id);
				$phones[$p->id]['phone'] = $p->number;
				$phones[$p->id]['default'] = $p->default;
			}
			
			$this->data['phones'] = $phones;
		}
		
		// Populate all addresses
		
		if(!empty($person->address->id))
		{
			foreach ($person->address->all as $a)
			{
				$addresses[$a->id]['addressid'] = $a->id;
				$addresses[$a->id]['list_of_addresstypes'] = $this->build_list_of_addresstypes($a->addresstype->id);
				$addresses[$a->id]['street'] = $a->street;
				$addresses[$a->id]['list_of_countries'] = $this->build_list_of_countries($a->location->country->id);
				$addresses[$a->id]['list_of_locations'] = $this->build_list_of_cities($a->location->country->id, $a->location->id);
				$addresses[$a->id]['default'] = $a->default;
			}
			
			$this->data['addresses'] = $addresses;
		}
		
		// Populate Work Experience
		
		if(!empty($person->workexperience->id))
		{
			foreach ($person->workexperience->all as $w)
			{
				$workexperiences[$w->id]['workid'] = $w->id;
				$workexperiences[$w->id]['list_of_workexperiencetypes'] = $this->build_list_of_workexperiencetypes($w->workexperiencetype->id);
				
				if(!empty($w->industry->id))
					$workexperiences[$w->id]['list_of_industries'] = $this->build_list_of_industries($w->industry->id);
				else
					$workexperiences[$w->id]['list_of_industries'] = $this->build_list_of_industries();
				
				$workexperiences[$w->id]['list_of_segments'] = $this->build_list_of_segments($w->segment->id);
				$workexperiences[$w->id]['list_of_verticals'] = $this->build_list_of_verticals($w->vertical->id);
				$workexperiences[$w->id]['list_of_responsibilities'] = $this->build_list_of_responsibilities($w->responsibility->id);
				$workexperiences[$w->id]['list_of_companies'] = $this->build_list_of_companies($w->company->id);
				
				if(!empty($w->location->id))
					$workexperiences[$w->id]['list_of_worklocations'] = $this->build_list_of_worklocations($w->location->id);
				else
					$workexperiences[$w->id]['list_of_worklocations'] = $this->build_list_of_worklocations();
					
				if(!empty($w->designation->id))
					$workexperiences[$w->id]['list_of_designations'] = $this->build_list_of_designations($w->designation->id);
				else
					$workexperiences[$w->id]['list_of_designations'] = $this->build_list_of_designations();
					
				$workexperiences[$w->id]['fromdate'] = $w->from_date;
				$workexperiences[$w->id]['todate'] = $w->to_date;
				$workexperiences[$w->id]['salary_fixed'] = $w->salary_fixed;
				$workexperiences[$w->id]['salary_variable'] = $w->salary_variable;
			}
			
			$this->data['workexperiences'] = $workexperiences;
		}
		
		// Populate Qualifications
		
		if (!empty($person->qualification->id))
		{
			foreach ($person->qualification->all as $q)
			{
				$qualifications[$q->id]['id'] = $q->id;
				
				if(!empty($q->qualificationtype->id))
					$qualifications[$q->id]['list_of_qualificationtypes'] = $this->build_list_of_qualificationtypes($q->qualificationtype->id);
				else
					$qualifications[$q->id]['list_of_qualificationtypes'] = $this->build_list_of_qualificationtypes();
					
				$qualifications[$q->id]['coursetypes'] = $this->build_coursetype_list($q->coursetype);
				
				if(!empty($q->institute->id))
					$qualifications[$q->id]['list_of_institutes'] = $this->build_list_of_institutes($q->institute->id);
				else
					$qualifications[$q->id]['list_of_institutes'] = $this->build_list_of_institutes();
				
				if(!empty($q->degree->id))
					$qualifications[$q->id]['list_of_degrees'] = $this->build_list_of_degrees($q->degree->id);
				else
					$qualifications[$q->id]['list_of_degrees'] = $this->build_list_of_degrees();
					
				$qualifications[$q->id]['fromdate'] = $q->from_date;
				$qualifications[$q->id]['todate'] = $q->to_date;
				$qualifications[$q->id]['score'] = $q->score;
				$qualifications[$q->id]['rank'] = $q->rank;
			}
			$this->data['qualifications'] = $qualifications;
		}
	}
	

	// It's time to get interesting! (really :p)
	// Here's where we build all the dropdown lists being used throughout the edit
	// form
	
	function build_gender_list($g = NULL)
	{
		$this->data['gender']['name'] = "gender";
		$this->data['gender']['options'] = array('M' => 'Male', 'F' => 'Female');
		$this->data['gender']['selected'] = ($g) ? $g : 'M';
	}
	
	// Contact Detail Related Lists
	
	function build_list_of_phonetypes($typeid = 0)
	{
		$phonetype = new Phonetype();
		
		$output = "<select id='phonetype' name='phonetype[]' >";
		
		$output .= $this->new_option('Phone Type', '0', $typeid);
		
		foreach($phonetype->get()->all as $row)
			$output .= $this->new_option($row->type, $row->id, $typeid);
			
		$output .= "</select'>";

        return $output;
	}
	
	function build_list_of_addresstypes($selected = 0)
	{
		$q = $this->db->query("select * from addresstypes" );
		
		$output = "<select id='addresstype' name='addresstype[]' >";
        
        $output .= $this->new_option('Choose Type', '0', $selected);

        foreach($q->result() as $row)
        {
            $output .= $this->new_option($row->type, $row->id, $selected);
        }

        $output .= "</select'>";

        return $output;
	}
	
	function build_list_of_countries($selected = '99')
	{
		$q = $this->db->query("select * from countries");
		
		$output = "<select id='countrylist' name='country[]' >";
        
        $output .= $this->new_option('Country', '0', $selected);
		
		foreach($q->result() as $row)
			$output .= $this->new_option($row->name, $row->id, $selected);
		
		$output .= "</select'>";

        return ($output);
	}
	
	function build_list_of_cities($countryid = 99, $cityid = 0)
	{
		$c = new Country();
		
		$c->get_by_id($countryid);
		$c->location->get();
		
		$output = "<select id='city' name='location[]' >";

        $output .= $this->new_option('Choose City', 0, $cityid);

        foreach ($c->location->all as $row)
		{
                $output .= $this->new_option($row->city, $row->id, $cityid);
        }

        $output .= "</select'>";

        return $output;
	}
	
	// Work Experience Related Lists
	
	function build_list_of_workcountries($selected = '99')
	{
		$q = $this->db->query("select * from countries");
		
		$output = "<select id='workcountrylist' name='workcountry[]' >";
        
        $output .= $this->new_option('Country', '0', $selected);
		
		foreach($q->result() as $row)
			$output .= $this->new_option($row->name, $row->id, $selected);
		
		$output .= "</select'>";

        return ($output);
	}
	

	function build_list_of_workexperiencetypes($selected_value = 0)
	{
		
		$o = new WorkExperienceType();
		
		$output = "<select id='workexperiencetype' name='workexperiencetype[]' >";
		
		if($selected_value != 0)
			$output .= $this->new_option('Delete This', 0, $selected_value);
		else
        	$output .= $this->new_option('Choose Work Type', 0, $selected_value);

		foreach($o->get()->all as $row)
			$output .= $this->new_option($row->type, $row->id, $selected_value);
		
		$output .= "</select'>";

        return $output;
	}
	
	function build_list_of_industries($selected_value = 0)
	{
		
		$o = new Industry();
		
		$output = "<select id='industry' name='industry[]' >";

        $output .= $this->new_option('Choose Industry', 0, $selected_value);

		foreach($o->get()->all as $row)
			$output .= $this->new_option($row->name, $row->id, $selected_value);
		
		$output .= "</select'>";

        return $output;
	}
	
	function build_list_of_segments($selected_value = 0)
	{
		
		$o = new Segment();
		
		$output = "<select id='segment' name='segment[]' >";

        $output .= $this->new_option('Choose Segment', 0, $selected_value);

		foreach($o->get()->all as $row)
			$output .= $this->new_option($row->name, $row->id, $selected_value);
		
		$output .= "</select'>";

        return $output;
	}
	
	function build_list_of_responsibilities($selected_value = 0)
	{
		
		$o = $this->db->query('select * from responsibilities');
		
		$output = "<select id='responsibility' name='responsibility[]' >";

        $output .= $this->new_option('Choose Role', 0, $selected_value);

		foreach($o->result() as $row)
			$output .= $this->new_option($row->name, $row->id, $selected_value);
		
		$output .= "</select'>";

        return $output;
	}
	
	function build_list_of_verticals($selected_value = 0)
	{
		
		$o = new Vertical();
		
		$output = "<select id='vertical' name='vertical[]' >";

        $output .= $this->new_option('Choose Function', 0, $selected_value);

		foreach($o->get()->all as $row)
			$output .= $this->new_option($row->name, $row->id, $selected_value);
		
		$output .= "</select'>";

        return $output;
	}

	function build_list_of_companies($selected_value = 0)
	{
		$o = $this->db->query('select * from companies order by name');
		
		$output = "<select id='company' name='company[]' >";

        $output .= $this->new_option('Choose Company', 0, $selected_value);

		foreach($o->result() as $row)
			$output .= $this->new_option($row->name, $row->id, $selected_value);
		
		$output .= "</select'>";

        return $output;
	}
	
	function build_list_of_worklocations($cityid = 0)
	{
		
		$l = new Location();
		
		$l->get();
		
		$output = "<select id='worklocation' name='worklocation[]' >";

        $output .= $this->new_option('Choose City', 0, $cityid);

        foreach ($l->all as $row)
		{
                $output .= $this->new_option($row->city, $row->id, $cityid);
        }

        $output .= "</select'>";

        return $output;
	}
	
	// Academics Related List
	
	function build_list_of_degrees($selected_value = 0)
	{
		
		$o = new degree();
		
		$output = "<select id='degree' name='degree[]'>";

        $output .= $this->new_option('Choose Degree', 0, $selected_value);
		$output .= $this->new_option('New Degree', -1, $selected_value);

		foreach($o->get()->all as $row)
			$output .= $this->new_option($row->name, $row->id, $selected_value);
		
		$output .= "</select'>";

        return $output;
	}
	
	function build_list_of_designations($selected_value = 0)
	{
		
		$o = $this->db->query("select * from designations");
		
		$output = "<select id='designation' name='designation[]'>";

        $output .= $this->new_option('Choose Designation', 0, $selected_value);
		$output .= $this->new_option('New Designation', -1, $selected_value);

		foreach($o->result() as $row)
			$output .= $this->new_option($row->name, $row->id, $selected_value);
		
		$output .= "</select'>";

        return $output;
	}
	
	function build_list_of_institutes($selected_value = 0)
	{
		
		$o = new Institute();
		
		$output = "<select id='institute' name='institute[]'>";

        $output .= $this->new_option('Choose Institute', 0, $selected_value);

		foreach($o->get()->all as $row)
			$output .= $this->new_option($row->name, $row->id, $selected_value);
		
		$output .= "</select'>";

        return $output;
	}

	function build_coursetype_list($selected = NULL)
	{
		$returnarr = array();
		$returnarr['name'] = "coursetype[]";
		$returnarr['options'] = array('0' => 'Course Type', 'FT' => 'Full Time', 'PT' => 'Part Time', 'C' => 'Correspondence/Distance Learning');
		$returnarr['selected'] = ($selected) ? $selected : 'FT';
		
		return $returnarr;
	}
	
	function build_list_of_coursetypes()
	{
		$output = "<select id='coursetype' name='coursetype[]' >";
		
		$output .= $this->new_option('Course Type', '0', '0');
		$output .= $this->new_option('Full Time', 'FT', '0');
		$output .= $this->new_option('Part Time', 'PT', '0');
		$output .= $this->new_option('Correspondence / Distance Learning', 'C', '0');
		$output .= "</select'>";

        return $output;
	}

	function build_list_of_qualificationtypes($selected_value = 0)
	{
		
		$o = $this->db->query("select * from qualificationtypes");
		
		$output = "<select id='qualificationtype' name='qualificationtype[]' >";
		
		if($selected_value != '0')
			$output .= $this->new_option('Remove This', '0', $selected_value);
		else
        	$output .= $this->new_option('Qualification Type', 0, $selected_value);

		foreach($o->result() as $row)
			$output .= $this->new_option($row->name, $row->id, $selected_value);
		
		$output .= "</select'>";

        return $output;
	}
	
	function new_option($text, $value, $value_cmp)
    {
        $output = "<option value=\"" . $value . "\"";

        if ($value === $value_cmp) 
        {
            $output .= " selected";
        }

        $output .= ">" . $text . "</option>";

        return ($output);
    }
	
}
